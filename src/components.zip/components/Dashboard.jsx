import React, { useState } from "react";
import { BrowserRouter } from "react-router-dom";
import Home from "./Dashboard/Home";
import { Link } from "react-router-dom";
import Items from "./Dashboard/Items";
import "../css/dashboard.css";
import Collapse from "react-bootstrap/Collapse";
import { RiArrowDownSLine } from "react-icons/ri";
import Customer from "./Dashboard/sales/Customer";
import Quotes from "./Dashboard/sales/Quotes";
import SalesOrder from "./Dashboard/sales/SalesOrder";
import DeliveryChallan from "./Dashboard/sales/DeliveryChallan";
import Invoices from "./Dashboard/sales/Invoices";
import PaymentReceived from "./Dashboard/sales/PaymentReceived";
import Vendors from "./Dashboard/puchases/Vendors";
import Expenses from "./Dashboard/puchases/Expenses";
import RecurringExpenses from "./Dashboard/puchases/RecurringExpenses";
import PurchaseOrders from "./Dashboard/puchases/PurchaseOrders";
import Bill from "./Dashboard/puchases/Bill";
import PaymentsMade from "./Dashboard/puchases/PaymentsMade";
import Project from "./Dashboard/TimeTracking/Project";
import Offcanvas from 'react-bootstrap/Offcanvas';
import Reports from "./Dashboard/reports/Reports";
import ManualJournal from "./Dashboard/accountant/ManualJournal";
import Budget from "./Dashboard/accountant/Budget";
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import Button from 'react-bootstrap/Button';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import { IoLogOutOutline } from "react-icons/io5";
import { IoSettingsOutline } from "react-icons/io5";


function Dashboard() {
  const [currentPage, setCurrentPage] = useState("");
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [open, setOpen] = useState(false);
  const [open2, setOpen2] = useState(false);
  const [open3, setOpen3] = useState(false);
  const [open4, setOpen4] = useState(false);

  const [isHighlighted, setIsHighlighted] = useState(false);
  const toggleHighlight = () => {
    setIsHighlighted(!isHighlighted);
  };



  const renderPage = () => {



    switch (currentPage) {
      case "/dashboard/home":
        return <Home />;
      case "/dashboard/items":
        return <Items />;
      case "/dashboard/sales/customer":
        return <Customer />;
      case "/dashboard/sales/quotes":
        return <Quotes />;
      case "/dashboard/sales/salesorder":
        return <SalesOrder />;
      case "/dashboard/sales/deliverychallan":
        return <DeliveryChallan />;
      case "/dashboard/sales/invoice":
        return <Invoices />;
      case "/dashboard/sales/payment-received":
        return <PaymentReceived />;
      case "/dashboard/purchase/vendors":
        return <Vendors />;
      case "/dashboard/purchase/expense":
        return <Expenses />;
      case "/dashboard/purchase/recurring-expense":
        return <RecurringExpenses />;
      case "/dashboard/purchase/purchaseorder":
        return <PurchaseOrders />;
      case "/dashboard/purchase/bill":
        return <Bill />;
      case "/dashboard/purchase/paymentsmade":
        return <PaymentsMade />;
      case "/dashboard/timetracking/projects":
        return <Project />;
        case "/dashboard/reports":
          return <Reports/>;
          case "/dashboard/accountant/manualjournal":
            return <ManualJournal/>;
            case "/dashboard/accountant/budget":
              return <Budget/>;
      default:
        return <Home />;
    }
  };
  return (
    <div>
      <div className="container-fluid">
<div className="row">
<Navbar className="bg-body-tertiary bg-dark" style={{height:'60px'}}>
      <Container>
        <Navbar.Brand href="#home" className="text-light ">Hello, John</Navbar.Brand>
        <IoSettingsOutline/>
        <Navbar.Toggle />
        <Navbar.Collapse className="justify-content-end">
          <Navbar.Text className="text-light">
     
        {['bottom'].map((placement) => (
        <OverlayTrigger
          trigger="click"
          key={placement}
          placement={placement}
          overlay={
            <Popover id={`popover-positioned-${placement}`} style={{backgroundColor:'aliceblue'}}>
              <Popover.Body>
                <div className="row" >
                  <div className="col-md-12">
                  <b>  jhone doe</b>
                  </div>
                  <div className="col-md-12">
                johndoe@gmail.com
                  </div>
                </div>
                <hr />
                <div className="row">
                  <div className="col-md-6 col-6">
                    <a href="/dashboard/profile" target="_blank">My Account</a>
                  </div>
                  <div className="col-md-6 col-6 text-end">
               <span style={{color:'red'}}>     <IoLogOutOutline/>&nbsp;Sign out</span>
                  </div>
                </div>
               
              </Popover.Body>
            </Popover>
          }
        >
           <div className="profilePicture">
          <img src="../images/profilePlaceholder.jpg" alt="" srcset=""  />
        </div>
        
        </OverlayTrigger>
      ))}

          </Navbar.Text>
        </Navbar.Collapse>
      </Container>
    </Navbar>          
</div>



        <div className="row">
{/* <div className="col hamburgerColumn ">
<img src="../images/hamburger.png" alt="" srcset=""  onClick={handleShow} />
</div> */}
          <div className="col-md-2 sidebarColumn overflow-auto sidebar forBoxSadow" >
        
            <div class="list-group h-100 border d-flex justify-content-evenly border-0">
              <Link
                class="list-group-item list-group-item-action text-start w-100 border-0"
                onClick={() => setCurrentPage("/dashboard/home")}
                
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/home.png" alt="" srcset="" />
                </span>
                Home
                <span class="badge float-end text-bg-primary rounded-pill">
                  14
                </span>
              </Link>
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setCurrentPage("/dashboard/items")}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/items.png" alt="" srcset="" />
                </span>
                Items
              </Link>

              {/* --------------Sales Collapse start-------- */}

              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setOpen(!open)}
                aria-controls="example-collapse-text"
                aria-expanded={open}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/cart.png" alt="" srcset="" />
                </span>
                Sales
                <span style={{ float: "right" }}>
                  <RiArrowDownSLine
                    style={{ color: "blueviolet", fontSize: "20px" }}
                  />
                </span>
              </Link>
              <Collapse in={open}>
                <div id="example-collapse-text">
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => setCurrentPage("/dashboard/sales/customer")}
                  >
                    Customers
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => setCurrentPage("/dashboard/sales/quotes")}
                  >
                    Quotes
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>
                      setCurrentPage("/dashboard/sales/salesorder")
                    }
                  >
                    Sales Orders
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>
                      setCurrentPage("/dashboard/sales/deliverychallan")
                    }
                  >
                    Delivery Challans
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => setCurrentPage("/dashboard/sales/invoice")}
                  >
                    Invoices
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>
                      setCurrentPage("/dashboard/sales/payment-received")
                    }
                  >
                    Payments Received
                  </Link>
                  {/* <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => setCurrentPage("/dashboard/home")}
                  >
                    Recurring Invoices
                  </Link> */}
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => setCurrentPage("/dashboard/items")}
                  >
                    Credit Notes
                  </Link>
                </div>
              </Collapse>

              {/* --------------Sales Collapse end-------- */}

              {/* --------------Purchase Collapse start-------- */}
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setOpen2(!open2)}
                aria-controls="example-collapse-text"
                aria-expanded={open2}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/bag.png" alt="" srcset="" />
                </span>
                Purchases
                <span style={{ float: "right" }}>
                  <RiArrowDownSLine
                    style={{ color: "blueviolet", fontSize: "20px" }}
                  />
                </span>
              </Link>

              <Collapse in={open2}>
                <div id="example-collapse-text">
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>
                      setCurrentPage("/dashboard/purchase/vendors")
                    }
                  >
                    Vendors
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>
                      setCurrentPage("/dashboard/purchase/expense")
                    }
                  >
                    Expenses
                  </Link>
                  {/* <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>
                      setCurrentPage("/dashboard/purchase/recurring-expense")
                    }
                  >
                    Recurring Expenses
                  </Link> */}
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>
                      setCurrentPage("/dashboard/purchase/purchaseorder")
                    }
                  >
                    Purchase Orders
                  </Link>
                  {/* <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => setCurrentPage("/dashboard/purchase/bill")}
                  >
                    Bills
                  </Link> */}
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>
                      setCurrentPage("/dashboard/purchase/paymentsmade")
                    }
                  >
                    Payments Made
                  </Link>
                  {/* <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => setCurrentPage("/dashboard/home")}
                  >
                    Recurring Bills
                  </Link> */}
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => setCurrentPage("/dashboard/items")}
                  >
                    Vendor Credits
                  </Link>
                </div>
              </Collapse>

              {/* --------------Purchase Collapse end-------- */}

              {/* --------------Time tracking Collapse start-------- */}
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setOpen3(!open3)}
                aria-controls="example-collapse-text"
                aria-expanded={open3}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/watch.png" alt="" srcset="" />
                </span>
                Time Tracking
                <span style={{ float: "right" }}>
                  <RiArrowDownSLine
                    style={{ color: "blueviolet", fontSize: "20px" }}
                  />
                </span>
              </Link>

              <Collapse in={open3}>
                <div id="example-collapse-text">
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>
                      setCurrentPage("/dashboard/timetracking/projects")
                    }
                  >
                    Projects
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => setCurrentPage("/dashboard/items")}
                  >
                    TimeSheet
                  </Link>
                </div>
              </Collapse>

              {/* --------time tracking collapse end--------- */}

              {/* --------------Accountant Collapse start-------- */}
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setOpen4(!open4)}
                aria-controls="example-collapse-text"
                aria-expanded={open4}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/accountant.png" alt="" srcset="" />
                </span>
                Accountant
                <span style={{ float: "right" }}>
                  <RiArrowDownSLine
                    style={{ color: "blueviolet", fontSize: "20px" }}
                  />
                </span>
              </Link>

              <Collapse in={open4}>
                <div id="example-collapse-text">
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => setCurrentPage("/dashboard/accountant/manualjournal")}
                  >
                    Manual Journals
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => setCurrentPage("/dashboard/items")}
                  >
                    Bulk Update
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => setCurrentPage("/dashboard/home")}
                  >
                    Currency Adjustments
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => setCurrentPage("/dashboard/items")}
                  >
                    Charts of Account
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => setCurrentPage("/dashboard/accountant/budget")}
                  >
                    Budgets
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => setCurrentPage("/dashboard/items")}
                  >
                    Transction Locking
                  </Link>
                </div>
              </Collapse>

              {/* --------------Accountant Collapse end-------- */}

{/* -------------------reports---------------- */}
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setCurrentPage("/dashboard/reports")}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/charts.png" alt="" srcset="" />
                </span>
               Reports
              </Link>

{/* -------------------reports end---------------- */}


{/* -------------------Payroll---------------- */}
<Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setCurrentPage("/dashboard/payroll")}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/payroll.png" alt="" srcset="" />
                </span>
               Payroll
              </Link>

{/* -------------------Payroll---------------- */}

            </div>
          </div>
          <div className="col-md-10  overflow-auto sidebar " >
            {renderPage()}
          </div>
        </div>
      </div>

{/* ---------------offcanvas------------- */}
<Offcanvas show={show}   onHide={handleClose} style={{background:'white'}}>
        <Offcanvas.Header closeButton >
          <Offcanvas.Title>Dashboard</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body className="border">
        <div class="list-group bg-transparent h-100 d-flex justify-content-evenly" >
              <Link
                class="list-group-item list-group-item-action text-start w-100 border-0"
                onClick={() => {
                  setCurrentPage("/dashboard/home");
                  setShow(false)
                }}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/home.png" alt="" srcset="" />
                </span>
                Home
                <span class="badge float-end text-bg-primary rounded-pill">
                  14
                </span>
              </Link>
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => {
                  setCurrentPage("/dashboard/items");
                  setShow(false)}}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/items.png" alt="" srcset="" />
                </span>
                Items
              </Link>

              {/* --------------Sales Collapse start-------- */}

              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setOpen(!open)}
                aria-controls="example-collapse-text"
                aria-expanded={open}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/cart.png" alt="" srcset="" />
                </span>
                Sales
                <span style={{ float: "right" }}>
                  <RiArrowDownSLine
                    style={{ color: "blueviolet", fontSize: "20px" }}
                  />
                </span>
              </Link>
              <Collapse in={open}>
                <div id="example-collapse-text">
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => {
                      setCurrentPage("/dashboard/sales/customer");
                    setShow(false)
                    }}
                  >
                    Customers
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => {
                      setCurrentPage("/dashboard/sales/quotes");
                      setShow(false)
                    }}
                  >
                    Quotes
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>
                      {setCurrentPage("/dashboard/sales/salesorder");
                        setShow(false)}
                    }
                  >
                    Sales Orders
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>{
                      setCurrentPage("/dashboard/sales/deliverychallan");
                      setShow(false)}
                    }
                  >
                    Delivery Challans
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => {
                      setCurrentPage("/dashboard/sales/invoice")
                    setShow(false)
                    }}
                  >
                    Invoices
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>{
                      setCurrentPage("/dashboard/sales/payment-received");
                      setShow(false);
                    }}
                  >
                    Payments Received
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => {setCurrentPage("/dashboard/home");
                      setShow(false);
                    }
                    }
                  >
                    Recurring Invoices
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => {setCurrentPage("/dashboard/items")
                      setShow(false)}
                    }
                  >
                    Credit Notes
                  </Link>
                </div>
              </Collapse>

              {/* --------------Sales Collapse end-------- */}

              {/* --------------Purchase Collapse start-------- */}
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setOpen2(!open2)}
                aria-controls="example-collapse-text"
                aria-expanded={open2}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/bag.png" alt="" srcset="" />
                </span>
                Purchases
                <span style={{ float: "right" }}>
                  <RiArrowDownSLine
                    style={{ color: "blueviolet", fontSize: "20px" }}
                  />
                </span>
              </Link>

              <Collapse in={open2}>
                <div id="example-collapse-text">
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>{
                      setCurrentPage("/dashboard/purchase/vendors");
                      setShow(false);
                    }
                    }
                  >
                    Vendors
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>{
                      setCurrentPage("/dashboard/purchase/expense");
                      setShow(false);
                    }
                    }
                  >
                    Expenses
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>{
                      setCurrentPage("/dashboard/purchase/recurring-expense")
                      setShow(false)}
                    }
                  >
                    Recurring Expenses
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>{
                      setCurrentPage("/dashboard/purchase/purchaseorder");
                      setShow(false)
                    }
                    }
                  >
                    Purchase Orders
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => {setCurrentPage("/dashboard/purchase/bill");
                      setShow(false)
                    }
                    }
                  >
                    Bills
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>{
                      setCurrentPage("/dashboard/purchase/paymentsmade")
                      setShow(false)
                    }
                    }
                  >
                    Payments Made
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>{ setCurrentPage("/dashboard/home")
                      setShow(false)
                    }
                    }
                  >
                    Recurring Bills
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => {setCurrentPage("/dashboard/items");
                      setShow(false)
                    }
                    }
                  >
                    Vendor Credits
                  </Link>
                </div>
              </Collapse>

              {/* --------------Purchase Collapse end-------- */}

              {/* --------------Time tracking Collapse start-------- */}
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setOpen3(!open3)}
                aria-controls="example-collapse-text"
                aria-expanded={open3}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/watch.png" alt="" srcset="" />
                </span>
                Time Tracking
                <span style={{ float: "right" }}>
                  <RiArrowDownSLine
                    style={{ color: "blueviolet", fontSize: "20px" }}
                  />
                </span>
              </Link>

              <Collapse in={open3}>
                <div id="example-collapse-text">
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>{
                      setCurrentPage("/dashboard/timetracking/projects");
                      setShow(false)
                    }
                    }
                  >
                    Projects
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() =>{

                    setCurrentPage("/dashboard/items");
                  setShow(false)
                  }
                    }
                  >
                    TimeSheet
                  </Link>
                </div>
              </Collapse>

              {/* --------time tracking collapse end--------- */}

              {/* --------------Accountant Collapse start-------- */}
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => setOpen4(!open4)}
                aria-controls="example-collapse-text"
                aria-expanded={open4}
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/accountant.png" alt="" srcset="" />
                </span>
                Accountant
                <span style={{ float: "right" }}>
                  <RiArrowDownSLine
                    style={{ color: "blueviolet", fontSize: "20px" }}
                  />
                </span>
              </Link>

              <Collapse in={open4}>
                <div id="example-collapse-text">
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>{ setCurrentPage("/dashboard/accountant/manualjournal");
                      setShow(false)}
                    }
                  >
                    Manual Journals
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => {setCurrentPage("/dashboard/items");
                      setShow(false);}
                    }
                  >
                    Bulk Update
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() => {setCurrentPage("/dashboard/home");
                      setShow(false)}
                    }
                  >
                    Currency Adjustments
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => {setCurrentPage("/dashboard/items");
                      setShow(false);}
                    }
                  >
                    Charts of Account
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start w-100 border-0"
                    onClick={() =>{ setCurrentPage("/dashboard/accountant/budget");
                      setShow(false)}
                    }
                  >
                    Budgets
                  </Link>
                  <Link
                    class="list-group-item list-group-item-action text-start border-0"
                    onClick={() => {setCurrentPage("/dashboard/items");
                      setShow(false);}
                    }
                  >
                    Transction Locking
                  </Link>
                </div>
              </Collapse>

              {/* --------------Accountant Collapse end-------- */}

 

           {/* -------------------reports---------------- */}
              <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() =>{ setCurrentPage("/dashboard/reports");
                  setShow(false)}
                }
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/charts.png" alt="" srcset="" />
                </span>
              Reports
              </Link>

{/* -------------------reports end---------------- */}

      {/* -------------------payroll---------------- */}
      <Link
                class="list-group-item list-group-item-action text-start border-0"
                onClick={() => {setCurrentPage("/dashboard/payroll");
                  setShow(false)}
                }
              >
                <span style={{ marginRight: "10px" }}>
                  <img src="../images/payroll.png" alt="" srcset="" />
                </span>
              Payroll
              </Link>

{/* -------------------payroll end---------------- */}


            </div>
        </Offcanvas.Body>
      </Offcanvas>

    </div>
  );
}

export default Dashboard;
