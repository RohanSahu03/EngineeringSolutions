import React, { useEffect, useRef } from "react";
import "../css/home.css";
import NavBar from "./Navbar";
import TextTransition, { presets } from "react-text-transition";
import { FaShieldAlt } from "react-icons/fa";
import { SiTicktick } from "react-icons/si";
import { FaFireExtinguisher } from "react-icons/fa";
import AOS from "aos";
import "aos/dist/aos.css";
import Accordion from "react-bootstrap/Accordion";
import { MdOutlinePhone } from "react-icons/md";
import { MdOutlineMail } from "react-icons/md";
import {useNavigate} from 'react-router-dom'

const TEXTS = [
  "Best Concrete Services For All Construction",
  "The Leading Manufacturer of Concrete",
  "Quality Concrete.The name says it.Our goodwill proves it.",
];

function Home() {
  const [index, setIndex] = React.useState(0);
  const myRef1 = useRef(null);
  const navigate=useNavigate()

  const goToService=()=>{
    navigate('/service')
  }

  const goToContact=()=>{
    navigate('/contactus')
  }

  useEffect(() => {
    const intervalId = setInterval(
      () => setIndex((index) => index + 1),
      4000 // every 3 seconds
    );
    return () => clearTimeout(intervalId);
  }, []);

  useEffect(() => {
    AOS.init({ duration: "900" });
  }, []);

  const scrollPage = () => {
    myRef1.current.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div>
      <div className="banner">
        <NavBar />
        <div className="innerDiv">
          <h4 data-aos="fade-up">BUILD OR REBUILD</h4>
          <h1 className="h1" data-aos="fade-up">
            Best Concrete Services For All Construction
          </h1>
          <br />
          <div className="row ">
            <div className="col-md-12 ">
              <div className="btns">
                <div>
                  <button className="serviceBtn" onClick={goToService}>OUR SERVICES</button>
                </div>
                <div>
                  <button className="contactBtn" onClick={goToContact}>CONTACT US</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="firstPart">
        <div className="left" data-aos="slide-up">
          <img src="../images/img1.jpg" alt="" srcset="" className="aboutImg" />
          <div className="cardd">
            <h5>THE BEST CONSTRUCTION COMPANY IN 2024</h5>
          </div>
        </div>
        <div className="right" data-aos="slide-up" ref={myRef1}>
          <h3>
            <img
              src="../images/cement-truck.png"
              alt=""
              srcset=""
              style={{ width: "50px", height: "50px", marginRight: "10px" }}
            />{" "}
            WE ARE CONCRETE THE BEST SOLUTION
          </h3>
          <p>
            Welcome to [Your Company Name], where reliability meets excellence
            in ready mix concrete services. With [number] years of industry
            expertise, we specialize in delivering high-quality concrete
            tailored to meet the unique needs of every project.{" "}
          </p>
          <br />
          <br />

          <h3>
            <img
              src="../images/cement-truck.png"
              alt=""
              srcset=""
              style={{ width: "50px", height: "50px", marginRight: "10px" }}
            />{" "}
            Quality & Liability
          </h3>
          <p>
            To be the leading provider of innovative and sustainable ready mix
            concrete solutions, setting the industry benchmark for quality,
            reliability, and customer satisfaction. Our mission is to deliver
            superior ready mix concrete products and services that meet and
            exceed our customers' expectations. We achieve this by :
          </p>
          <ul>
            <li>Committing to Quality</li>
            <li>Embracing Innovation</li>
            <li>Prioritizing Customer Needs</li>
            <li>Fostering Sustainability</li>
          </ul>
        </div>
      </div>

      <div className="container-fluid mt-md-5" data-aos="slide-up">
        <div className="row " style={{ backgroundColor: "#f5f5f5" }}>
          <div className="col-md-6 my-4 d-flex justify-content-center ">
            <div
              class="card border-0"
              style={{
                width: "32rem",
                padding: "10px",
                backgroundColor: "#f5f5f5",
              }}
            >
              <h3 className="quality">QUALITY POLICY</h3>
              <div className="hrline"></div>
              <div className="row mt-4">
                <div className="col-md-2 ">
                  <FaShieldAlt className="shield" />
                </div>
                <div className="col-md-10 ">
                  <span style={{ fontWeight: "bold", textAlign: "left" }}>
                    {" "}
                    we are committed to delivering superior quality ready mix
                    concrete .
                  </span>
                  <ul>
                    <li>
                      <SiTicktick className="tick" />
                      We adhere strictly to industry standards and regulations
                      in every aspect of our operations, ensuring the highest
                      level of quality and safety in our products.
                    </li>
                    <li>
                      <SiTicktick className="tick" /> We continuously improve
                      our processes, technologies, and services to enhance
                      efficiency, reliability, and customer satisfaction
                    </li>
                    <li>
                      <SiTicktick className="tick" />
                      We implement rigorous quality control measures at every
                      stage of production, from raw materials sourcing to final
                      delivery, to ensure the consistency and reliability of our
                      concrete mixes.
                    </li>
                    <li>
                      <SiTicktick className="tick" /> We prioritize
                      understanding and meeting our customers' needs and
                      specifications, providing customized solutions and
                      responsive service to achieve their project objectives.
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-6 d-flex justify-content-center">
            <div
              class="card border-0 my-4"
              style={{
                width: "32rem",
                padding: "10px",
                backgroundColor: "#f5f5f5",
              }}
            >
              <h3 className="quality">SAFETY POLICY</h3>
              <div className="hrline"></div>
              <div className="row mt-4">
                <div className="col-md-2 ">
                  <FaFireExtinguisher className="shield" />
                </div>
                <div className="col-md-10 ">
                  <span style={{ fontWeight: "bold", textAlign: "left" }}>
                    {" "}
                    We are committed to maintaining a safe and healthy workplace
                    and ensuring that safety is ingrained in everything we do.
                  </span>
                  <ul>
                    <li>
                      <SiTicktick className="tick" />
                      We comply with all applicable health, safety, and
                      environmental regulations, striving to exceed minimum
                      legal requirements to protect our workforce and
                      stakeholders.
                    </li>
                    <li>
                      <SiTicktick className="tick" />
                      We foster a safety-first culture where every employee is
                      responsible for their safety and the safety of those
                      around them. We promote awareness, accountability, and
                      continuous improvement in safety practices.
                    </li>
                    <li>
                      <SiTicktick className="tick" />
                      We provide ongoing safety training and development
                      programs for our employees to equip them with the
                      knowledge and skills necessary to work safely and prevent
                      accidents.
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="chooseUsPart" data-aos="slide-up">
        <div className="innerContainer mt-3">
          <div className="heading">
            <div className="hline"></div>
            <h2>Why Choose Us</h2>
            <div className="hline"></div>
          </div>

          <div className="reasons">
            <div className="innerCard">
              <img src="../images/durable.png" alt="" srcset="" />
              <p>Durable Concrete</p>
            </div>
            <div className="innerCard">
              <img src="../images/environment.png" alt="" srcset="" />
              <p>Environment Friendly</p>
            </div>
            <div className="innerCard">
              <img src="../images/delivery.png" alt="" srcset="" />
              <p>Timely Delivery</p>
            </div>
            <div className="innerCard">
              <img src="../images/cost.png" alt="" srcset="" />
              <p>Cost Effective</p>
            </div>
          </div>
        </div>
      </div>

      {/* <div className="container-fluid " style={{backgroundColor:'#f5f5f5'}} >
  <div className="row" >
  <div className="heading mt-5">
            <div className="hline"></div>
            <h2>Our Services</h2>
            <div className="hline"></div>
           </div>
  </div>
  <div className="row pb-5 mt-5 d-flex justify-content-around">
   <div className="col-md-3  gy-3" data-aos='slide-up'>
   <div class="card border-0 serviceCard" style={{width: '100%',height:'12rem'}}>
  <div class="card-body">
    <h5 class="card-title">
      <img src="../images/icon1.jpg" alt="" srcset="" className="icon"/>
    </h5>
    <h6 class="card-subtitle mb-2 text-muted">Fiber-reinforced Concrete</h6>
    <p class="card-text">Concrete designed with steel or synthetic fibers. Steel f...</p>
    <a href="/service" class="card-link">View More</a>
  </div>
</div>
   </div>
   <div className="col-md-3  gy-3" data-aos='slide-up'>
   <div class="card border-0 serviceCard" style={{width: '100%',height:'12rem'}}>
  <div class="card-body">
    <h5 class="card-title">
      <img src="../images/icon2.jpg" alt="" srcset="" className="icon"/>
    </h5>
    <h6 class="card-subtitle mb-2 text-muted">Self-Consolidating Concrete (SCC)
    </h6>
    <p class="card-text">SCC is type of concrete which has high flow and is design...</p>
    <a href="/service" class="card-link">View More</a>
  </div>
</div>
   </div>
   <div className="col-md-3  gy-3" data-aos='slide-up'>
   <div class="card border-0 serviceCard" style={{width: '100%',height:'12rem'}}>
  <div class="card-body">
    <h5 class="card-title">
      <img src="../images/icon4.png" alt="" srcset="" className="icon"/>
    </h5>
    <h6 class="card-subtitle mb-2 text-muted">Packcrete
    </h6>
    <p class="card-text">Our ready to use and tailor made concrete available to pu...</p>
    <a href="/service" class="card-link">View More</a>
  </div>
</div>
   </div>
   <div className="col-md-3 gy-3" data-aos='slide-up'>
   <div class="card border-0 serviceCard" style={{width: '100%',height:'12rem'}}>
  <div class="card-body">
    <h5 class="card-title">
      <img src="../images/icon3.png" alt="" srcset="" className="icon"/>
    </h5>
    <h6 class="card-subtitle mb-2 text-muted">Pervious Concrete
    </h6>
    <p class="card-text">Because of its unique design mix, pervious concrete is a....</p>
    <a href="/service" class="card-link">View More</a>
  </div>
</div>
   </div>
   <div className="col-md-3 gy-3" data-aos='slide-up'>
   <div class="card border-0 serviceCard" style={{width: '100%',height:'12rem'}}>
  <div class="card-body">
    <h5 class="card-title">
      <img src="../images/icon2.jpg" alt="" srcset="" className="icon"/>
    </h5>
    <h6 class="card-subtitle mb-2 text-muted">Standard Ready-Mix Concrete
    </h6>
    <p class="card-text">Standard ready-mix concrete is the most common form of co...</p>
    <a href="/service" class="card-link">View More</a>
  </div>
</div>
   </div>
    </div>
</div> */}

      <div className="container-fluid mt-5">
        <div className="row">
          <h5 className="serviceHead">OUR SERVICES</h5>
        </div>
        <div className="row text-center d-flex justify-content-center ">
          <h1 className="serviceHead2">YOUR SATISFACTION IS OUR CONCERN</h1>
        </div>

        <div className="row mt-5">
          <div className="col-md-6">
            <div className="row">
              <div className="col-md-10">
                <div className="row">
                  <div className="col-md-10 servicePart text-end">
                    <h5>BUILDING SERVICE</h5>
                    <p>
                      Sed tristique dui ut nunc cursus, ut convallis neque
                      vehicula. Sed ligula odio
                    </p>
                  </div>
                  <div className="col-md-2">
                    <img src="../images/shield.png" alt="" srcset="" />
                  </div>
                </div>
              </div>
              <div className="col-md-8">
                <div className="row">
                  <div className="col-md-10 servicePart text-end">
                    <h5>BUILDING SERVICE</h5>
                    <p>
                      Sed tristique dui ut nunc cursus, ut convallis neque
                      vehicula. Sed ligula odio
                    </p>
                  </div>
                  <div className="col-md-2">
                    <img src="../images/shield.png" alt="" srcset="" />
                  </div>
                </div>
              </div>

              {/* ---------------------- */}

              <div className="row border serviceRow">
                <div className="col-md-6">
                  <div className="row serviceRow1">
                    <h1>207</h1>
                    <p>HAPPY CLIENT</p>
                  </div>
                </div>
                <div className="col-md-5">
                  <div className="row serviceRow1">
                    <h1>214</h1>
                    <p>COMPLETED PROJECT</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-2 d-flex justify-content-center align-items-center myCol2" style={{position:'absolute',right:'41%'}}>
            <div className="empImg">
              <img
                src="../images/employee.png"
                alt=""
                srcset=""
                className="employee"
              />
            </div>
          </div>

          <div className="col-md-6 ps-0">
            <div className="row d-fle justify-content-end">
              <div className="col-md-10">
                <div className="row">
                  <div className="col-md-2 text-start">
                    <img src="../images/shield.png" alt="" srcset="" />
                  </div>
                  <div className="col-md-10 servicePart text-start">
                    <h5>BUILDING SERVICE</h5>
                    <p>
                      Sed tristique dui ut nunc cursus, ut convallis neque
                      vehicula. Sed ligula odio
                    </p>
                  </div>
                </div>
              </div>
              <div className="col-md-8">
                <div className="row d-flex justify-content-end">
                  <div className="col-md-2 text-start">
                    <img src="../images/shield.png" alt="" srcset="" />
                  </div>
                  <div className="col-md-10 servicePart text-start">
                    <h5>BUILDING SERVICE</h5>
                    <p>
                      Sed tristique dui ut nunc cursus, ut convallis neque
                      vehicula. Sed ligula odio
                    </p>
                  </div>
                </div>
              </div>

              {/* --------------------------------------------- */}
              <div className="row border serviceRow">
                <div className="col-md-6">
                  <div className="row serviceRow1">
                    <h1>98</h1>
                    <p>PROFESSIONAL TEAM</p>
                  </div>
                </div>
                <div className="col-md-5">
                  <div className="row serviceRow1">
                    <h1>124</h1>
                    <p>AWWARD WINNING</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 
<div className="container-fluid">
<div className="row p-md-5 p-2">
<div className="col-md-6">
  <div className="row text-start">
  <h5 className="faqHead">FAQ</h5>
  </div>
<div className="row text-start">
    <h1 className="faqHead2">THE MOST QUESTION WE HAD</h1>
    <p>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
    </p>
  </div>
  <div className="row text-start mt-4">
  <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0">
        <Accordion.Header className="accordionHead"> HOW TO CHANGE MY PHOTO FROM ADMIN DASHBOARD ?</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header className="accordionHead">HOW TO CHANGE MY PASSWORD EASILY ?</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. 
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header className="accordionHead">HOW TO RESET MY PASSWORD EASILY ?</Accordion.Header>
        <Accordion.Body>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. 
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>
  </div>
</div>
<div className="col-md-6 d-flex justify-content-center align-items-center">
  <div className="faqImg">
<img src="../images/faq.jpg" alt="" srcset="" />
  </div>
</div>
  </div>
</div> */}

      <div className="contactInfo" data-aos="slide-up">
        <div className="content">
          <h2>Get Started Today</h2>
          <p>
            Whether you have a specific project in mind or need guidance on the
            best concrete solutions for your needs, [Company Name] is here to
            help. Contact us today to schedule a consultation or request a
            quote. Let us bring your concrete visions to life with precision and
            professionalism.
          </p>

          <div className="div">
            <MdOutlinePhone className="callIcon" />
            &nbsp;&nbsp;&nbsp;&nbsp; +91-72332323
          </div>
          <div className="div">
            <MdOutlineMail className="callIcon" />
            &nbsp;&nbsp; xyzinfo@gmail.com
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
