import React from 'react'
import NavBar from './Navbar'
import '../css/signup.css'


function SignUp() {

  const gotoLogin=()=>{
    window.location.href="/login"
  }

  return (
    <div>
          <NavBar/>
       <div className="container-fluid mainContainer">
       <div class="card mt-3" style={{width: '35rem'}}> 
       <span style={{fontWeight:'400',fontSize:'25px',paddingLeft:'0px',marginTop:'20px',  fontFamily: "Playwrite DE Grund",fontStyle:'cursive'}}>Sign Up</span>
  <div class="card-body">
    <input type="text" name="" id="" className='myInput' placeholder='Company Name'/>
    <input type="email" name="" id="" className='myInput' placeholder='Email Address'/>
    <input type="tel" name="" id="" className='myInput' placeholder='Mobile Number'/>
    <input type="password" name="" id="" className='myInput' placeholder='Password'/>
    <select name="" id="" className='myInput'>
        <option value="">India</option>
        <option value="">India</option>
        <option value="">India</option>
        <option value="">India</option>
        <option value="">India</option>
    </select>
    <select name="" id="" className='myInput'>
        <option value="">Karnataka</option>
        <option value="">Telangana</option>
        <option value="">Tamil Nadu</option>
        <option value="">Aandhra</option>
    </select>
    <br />
<br />
  <input type="checkbox" aria-label="Checkbox for following text input"/>I agree to the <a href="">Terms of Service</a> and  <a href="">Privacy Policy</a>.
  <br />
<small>Please read and accept the Terms of Service and Privacy Policy</small>
    <br />
    <button  className='registerBtn' onClick={gotoLogin}>
CREATE ACCOUNT
    </button>
    <br />
    <b>you already have an account ?  <a href="">SignIn</a></b>
   
  </div>
</div>




       </div>
    </div>
  )
}

export default SignUp