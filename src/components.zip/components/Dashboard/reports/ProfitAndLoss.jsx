import React from 'react'

function ProfitAndLoss() {
  return (
    <div>
        <div className="row">
            <div className="col-md-12">
                <small><i>Company Name</i></small>
                <h5>Profit & Loss</h5>
                <p>From : 01/06/2024 To 30/06/2024</p>
            </div>
        </div>
    </div>
  )
}

export default ProfitAndLoss