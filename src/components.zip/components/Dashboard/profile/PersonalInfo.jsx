import React, { useState,useRef } from 'react'
import { MdEdit } from "react-icons/md";
import { MdModeEditOutline } from "react-icons/md";
import { MdDeleteForever } from "react-icons/md";

function PersonalInfo() {
const [firstname,setFirstName]=useState('John')
const [lastname,setLastName]=useState('Doe')
const [displayname,setDisplayName]=useState('JhonDoe')
const [country,setCountry]=useState('India')
const [state,setState]=useState('Karnataka')
const [gender,setGender]=useState('')
const [input1,setInput1]=useState(true)
const [input2,setInput2]=useState(true)
const [input3,setInput3]=useState(true)
const [input4,setInput4]=useState(true)
const [input5,setInput5]=useState(true)
const [input6,setInput6]=useState(true)
const fileInputRef = useRef(null);

const handleClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div>
        <div className="container ">
          <div className="row text-start mt-5 ">
            <h3>Profile</h3>
          </div>
            <div className="row justify-content-center " style={{boxShadow: 'rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px',background:'aliceblue'}}>
                <div className="col-md-12 p-md-5 p-2">
          <div className="row">
            <div className="col-md-1 col-3">
            <div className='profilePic'>
          <img src="../images/profilePlaceholder.jpg" alt="" srcset=""  />
          <button className='editBtn' onClick={handleClick}>
       <img src="../images/edit.png" alt="" srcset="" /> edit
      </button>
        </div>
            </div>
            <div className="col-md-5 col-9 text-start">
                <h4>User Name</h4>
                <p>username@gmail.com</p>
            </div>
          </div>
    
                </div>
<div className="col-md-12 px-md-5 px-2 my-2">
    <div className="row py-3">
        <div className="col-md-6">
           <div className="row">
            <div className="col-md-12 text-start">
                <small>First Name</small>
            </div>
            <div className="col-md-12  text-start">
                <input type="text" className="form-control profileInput" placeholder="Full Name" value={firstname} onChange={(e)=>setFirstName(e.target.value)} disabled={input1} required/>
                <MdModeEditOutline className='pencil' onClick={()=>setInput1(false)}/>
            </div>
           </div>
        </div>
        <div className="col-md-6">
        <div className="row">
            <div className="col-md-12 text-start">
                <small>Last Name</small>
            </div>
            <div className="col-md-12  text-start">
                <input type="text" className="form-control profileInput"  value={lastname} onChange={(e)=>setLastName(e.target.value)} disabled={input2} required/>
                <MdModeEditOutline className='pencil' onClick={()=>setInput2(false)}/>
            </div>
           </div>
        </div>
    </div>
</div>

<div className="col-md-12 px-md-5 px-2 my-2">
    <div className="row">
        <div className="col-md-6">
           <div className="row">
            <div className="col-md-12 text-start">
                <small>Display Name</small>
            </div>
            <div className="col-md-12  text-start">
                <input type="text" className="form-control profileInput" placeholder="Full Name" value={displayname} onChange={(e)=>setDisplayName(e.target.value)} disabled={input3} required/>
                <MdModeEditOutline className='pencil' onClick={()=>setInput3(false)}/>
            </div>
           </div>
        </div>
        <div className="col-md-6">
        <div className="row">
            <div className="col-md-12 text-start">
                <small>Gender</small>
            </div>
            <div className="col-md-12  text-start">
            <select
            className="form-select profileInput"
            id="inputGroupSelect03"
            aria-label="Example select with button addon"
            placeholder='choose a proper challan type'
            disabled={input4}
            onChange={(e)=>setGender(e.target.value)}
          >
               <option value="Net-15"></option>
            <option value="Net-15">Male</option>
            <option value="Net-30">Female</option>
            <option value="Net-45">I'd prefer not to say</option>
          </select>
                <MdModeEditOutline className='pencil' onClick={()=>setInput4(false)}/>
            </div>
           </div>
        </div>
    </div>
</div>

<div className="col-md-12 px-md-5 px-2 my-2">
    <div className="row">
        <div className="col-md-6">
           <div className="row">
            <div className="col-md-12 text-start">
                <small>Country/Region</small>
            </div>
            <div className="col-md-12  text-start">
            <select
            className="form-select profileInput"
            id="inputGroupSelect03"
            aria-label="Example select with button addon"
            placeholder='choose a proper challan type'
            disabled={input4}
            onChange={(e)=>setCountry(e.target.value)}
            value={country}
          >
               <option value="Net-15"></option>
            <option value="Net-15">India</option>
            <option value="Net-30">China</option>
            <option value="Net-45">Nepal</option>
          </select>
                <MdModeEditOutline className='pencil' onClick={()=>setInput5(false)}/>
            </div>
           </div>
        </div>
        <div className="col-md-6">
        <div className="row">
            <div className="col-md-12 text-start">
                <small>State</small>
            </div>
            <div className="col-md-12  text-start">
            <select
            className="form-select profileInput"
            id="inputGroupSelect03"
            aria-label="Example select with button addon"
            placeholder='choose a proper challan type'
            disabled={input4}
            value={state}
            onChange={(e)=>setState(e.target.value)}
          >
               <option value="Net-15"></option>
            <option value="Net-15">Karnataka</option>
            <option value="Net-30">Maharastra</option>
            <option value="Net-45">Telangana</option>
          </select>
                <MdModeEditOutline className='pencil' onClick={()=>setInput6(false)}/>
            </div>
           </div>
        </div>
    </div>
</div>

<div className="col px-md-5 px-2 my-4 ">
<button type="button" class="btn btn-secondary">Save</button>
&nbsp;&nbsp;&nbsp;
<button type="button" class="btn btn-info">Cancel</button>
</div>

            </div>


            <div className="row justify-content-center mt-5 p-md-5 p-2" style={{boxShadow: 'rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px',background:'aliceblue'}}>
            <div className="col-md-12 text-start ">
                <h4>My Email Address</h4>
            </div>
            <div className="col-md-12 text-start ">
                <p>You can use the following email addresses to sign in to your account and also to reset your password if you ever forget it.</p>
            </div>
            <div className="row mt-3">
                <div className="col-md-6 col-6 text-start ">
              <div className="row">
                <div className="col-md-2">
                <img src="../images/email.png" alt="" srcset=""  className='emailPic'/>
            
                </div>
                <div className="col-md-8">
                <h6>JohnDoe@gmail.com</h6>
                </div>
              </div>
                </div>
                <div className="col-md-6 col-6 text-end">
<MdDeleteForever style={{fontSize:'25px'}}/>
                </div>
                <div className="col-md-12 mt-1">
                <b>    + Add Email Address</b>
                </div>
            </div>
            </div>

            <div className="row justify-content-center mt-5 p-md-5 p-2 mb-4" style={{boxShadow: 'rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px',background:'aliceblue'}}>
            <div className="col-md-12 text-start ">
                <h4>My Mobile Number</h4>
            </div>
            <div className="col-md-12 text-start ">
                <p>View and manage all of the mobile numbers associated with your account.</p>
            </div>
            <div className="row mt-3">
                <div className="col-md-6 col-6 text-start ">
              <div className="row">
                <div className="col-md-2">
                <img src="../images/call.png" alt="" srcset=""  className='emailPic'/>
            
                </div>
                <div className="col-md-8">
                <h6>+9189474349</h6>
                </div>
              </div>
                </div>
                <div className="col-md-6 col-6 text-end">
<MdDeleteForever style={{fontSize:'25px'}}/>
                </div>
                <div className="col-md-12 mt-1">
                <b>    + Add Mobile Number</b>
                </div>
            </div>
            </div>
 
            <input
        type="file"
        ref={fileInputRef}
        style={{ display: 'none' }}
  
      />

        </div>
    </div>
  )
}

export default PersonalInfo