import { useState, useRef } from 'react';
import Button from 'react-bootstrap/Button';
import Overlay from 'react-bootstrap/Overlay';
import '../../css/dashboard/home.css'
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import { AiFillPlusCircle } from "react-icons/ai";
import { LiaRupeeSignSolid } from "react-icons/lia";
import { TiArrowSortedDown } from "react-icons/ti";
import Col from 'react-bootstrap/Col';
import Nav from 'react-bootstrap/Nav';
import Row from 'react-bootstrap/Row';
import Placeholder from 'react-bootstrap/Placeholder';



function Home() {
    const [show, setShow] = useState(false);
    const [show1, setShow1] = useState(false);
    const target = useRef(null);
    const target2 = useRef(null);
  return (
    <div> 
        <div className="row  py-3 d-flex " >
            <div className="col-md-1 col-6">
            <div className="profileImg">
                <img src="../images/company.png" alt="" srcset=""/>
            </div>
            </div>
            <div className="col-md-3 col-6">
            <div className='text'>
               <b> Hello, XYZ</b>
                <br />
                <small><i> company name</i></small>
            </div>
            </div>
        </div>

        <div className="row">
        <Tabs
      defaultActiveKey="home"
      id="fill-tab-example"
      className="mb-3 border-0 pt-2"
      fill
    >
      <Tab eventKey="home" title="Dashboard">
       <div className="row  g-3">
        <div className="col-md-6">
        <div class="card">
      <div class="card-body">
        <h5 class="card-title bg-body-secondary text-start ">Total Receivables <span className='float-end text-primary'><AiFillPlusCircle data-bs-container="body" data-bs-toggle="popover" data-bs-placement="bottom" data-bs-content="Bottom popover"/><span style={{fontSize:'13px'}}>New</span></span></h5>
        <div className='w-100  invoiceMoney'>
            Total Unpaid Invoice <LiaRupeeSignSolid/> 0.00 
        </div>
   <div className="row ">
    <div className="col-md-6 py-2 text-start">
        CURRENT
        <br />
        <LiaRupeeSignSolid/> 0.00
    </div>
    <div className="col-md-6 py-2 text-start">
        OVERDUE
        <br />
        <LiaRupeeSignSolid/>  <Button variant="transparent" ref={target} onClick={() => setShow(!show)}>
        0.00  <TiArrowSortedDown/>
      </Button>
      <Overlay target={target.current} show={show} placement="bottom">
        {({
          placement: _placement,
          arrowProps: _arrowProps,
          show: _show,
          popper: _popper,
          hasDoneInitialMeasure: _hasDoneInitialMeasure,
          ...props
        }) => (
          <div
            {...props}
            style={{
              position: 'absolute',
              backgroundColor: 'aliceblue',
              padding: '2px 10px',
              color: 'black',
              borderRadius: 3,
              ...props.style,
            }}
          >
       <ul class="list-group">
  <li class="list-group-item list-group-item-action">1-15 days <span> <LiaRupeeSignSolid style={{marginLeft:'80px'}}/> 0.00</span></li>
  <li class="list-group-item list-group-item-action">16-30 days <span> <LiaRupeeSignSolid style={{marginLeft:'80px'}}/> 0.00</span></li>
  <li class="list-group-item list-group-item-action">31-45 days <span> <LiaRupeeSignSolid style={{marginLeft:'80px'}}/> 0.00</span></li>
  <li class="list-group-item list-group-item-action">Above 45 days <span> <LiaRupeeSignSolid style={{marginLeft:'80px'}}/> 0.00</span></li>

</ul>

          </div>
        )}
      </Overlay>
    </div>
   </div>
      </div>
    </div>
        </div>
     <div className="col-md-6">
     <div class="card">
      <div class="card-body">
        <h5 class="card-title bg-body-secondary text-start ">Total Receivables <span className='float-end text-primary'><AiFillPlusCircle data-bs-container="body" data-bs-toggle="popover" data-bs-placement="bottom" data-bs-content="Bottom popover"/><span style={{fontSize:'13px'}}>New</span></span></h5>
        <div className='w-100  invoiceMoney'>
            Total Unpaid Invoice <LiaRupeeSignSolid/> 0.00 
        </div>
   <div className="row ">
    <div className="col-md-6 py-2 text-start">
        CURRENT
        <br />
        <LiaRupeeSignSolid/> 0.00
    </div>
    <div className="col-md-6 py-2 text-start">
        OVERDUE
        <br />
        <LiaRupeeSignSolid/>  <Button variant="transparent" ref={target2} onClick={() => setShow1(!show1)}>
        0.00  <TiArrowSortedDown/>
      </Button>
      <Overlay target={target2.current} show={show1} placement="bottom">
        {({
          placement: _placement,
          arrowProps: _arrowProps,
          show: _show,
          popper: _popper,
          hasDoneInitialMeasure: _hasDoneInitialMeasure,
          ...propss
        }) => (
          <div
            {...propss}
            style={{
              position: 'absolute',
              backgroundColor: 'aliceblue',
              padding: '2px 10px',
              color: 'black',
              borderRadius: 3,
              ...propss.style,
            }}
          >
       <ul class="list-group">
  <li class="list-group-item list-group-item-action">1-15 days <span> <LiaRupeeSignSolid style={{marginLeft:'80px'}}/> 0.00</span></li>
  <li class="list-group-item list-group-item-action">16-30 days <span> <LiaRupeeSignSolid style={{marginLeft:'80px'}}/> 0.00</span></li>
  <li class="list-group-item list-group-item-action">31-45 days <span> <LiaRupeeSignSolid style={{marginLeft:'80px'}}/> 0.00</span></li>
  <li class="list-group-item list-group-item-action">Above 45 days <span> <LiaRupeeSignSolid style={{marginLeft:'80px'}}/> 0.00</span></li>

</ul>

          </div>
        )}
      </Overlay>
    </div>
   </div>
      </div>
    </div>
     </div>
       </div>

      </Tab>
      <Tab eventKey="profile" title="Getting Started">

      <div class="card bg-light text-dark ">
    <div class="card-body py-5">
      <h4>Welcome to XYZ</h4>
      <p><i>"Empower Your Business with Seamless Accounting Solutions."</i></p>
      <br />
      <Tab.Container id="left-tabs-example" defaultActiveKey="first">
      <Row className="d-flex justify-content-center">
        <Col sm={3}>
          <Nav variant="pills" className="flex-column">
            <Nav.Item >
              <Nav.Link eventKey="first" >
                <small>add organization details</small>
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="second" >
              <small>create tour first invoice</small>
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="third" >
              <small>set up banking and journal</small>
              </Nav.Link>
            </Nav.Item>
          </Nav>
        </Col>
        <Col sm={6} className='border'>
          <Tab.Content>
            <Tab.Pane eventKey="first">
              <h6>Add organization details</h6>
              <p><small>Add your organization’s address and tax details to xyz to auto-populate them when you create transactions. Also, add users to provide access to your employees and accountants.</small></p>
              <hr />
              <small><a href="">Add Address</a></small>
            </Tab.Pane>
            <Tab.Pane eventKey="second"> <h6>Add organization details</h6>
              <p><small>Create a customer, add an item, and create an invoice. You can choose customized templates for the invoice and send them.</small></p>
              <hr />
         <div class="row">
          <div className="col-md-12">
          <small><a href="" className='d-inline'>Add Customer</a></small>
          </div>
          <div className="col-md-12"></div>
          <small><a href="">Create Invoice</a></small>
         </div>
              </Tab.Pane>
            <Tab.Pane eventKey="third">
            <h6>Set up banking and journals</h6>
              <p><small>Connect your bank account to XYZ and fetch feeds to reconcile them with transactions.Also, you can record manual journals for unique transactions.</small></p>
              <button type="button" class="btn btn-primary btn-sm">Add Bank Account</button>
              <hr />
         {/* <div class="row">
          <div className="col-md-12">
          <small><a href="" className='d-inline'>Add Customer</a></small>
          </div>
          <div className="col-md-12"></div>
          <small><a href="">Create Invoice</a></small>
         </div> */}
            </Tab.Pane>
          </Tab.Content>
        </Col>
      </Row>
    </Tab.Container>
    </div>
  </div>  


      </Tab>
      <Tab eventKey="longer-tab" title="Announcement">
      <p aria-hidden="true">
        <Placeholder xs={6} />
      </p>

      <Placeholder.Button xs={4} aria-hidden="true" />
      </Tab>
      {/* <Tab eventKey="contact" title="Contact" disabled>
        Tab content for Contact
      </Tab> */}
    </Tabs>
        </div>
    </div>
  )
}

export default Home