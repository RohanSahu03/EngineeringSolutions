import React,{useState} from 'react'
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

function Vendors() {
    const [type, setType] = useState("");
    const [name, setName] = useState("");
    const [lastname, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
  
    const handleRadioChange = (event) => {
      setType(event.target.value);
    };
  return (
    <div>
              <div className="row border-bottom py-2 text-start d-flex ">
        <h3>New Vendor</h3>
      </div>

      <form class="row g-3 needs-validation" novalidate style={{width:'100%'}}>
  
        {/* --customer name---- */}
        <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Primary Contact*
            </label>
          </div>
          <div className="col-md-10">
            <div className="row gy-1">
              <div className="col-md-5">
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  required
                  onChange={(e) => setName(e.target.value)}
                  value={name}
                  placeholder="First Name"
                />
              </div>
              <div className="col-md-5">
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  required
                  onChange={(e) => setLastName(e.target.value)}
                  value={lastname}
                  placeholder="Last Name"
                />
              </div>
            </div>
          </div>
        </div>

        {/* ------company name---------- */}
        <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Company Name
            </label>
          </div>
          <div className="col-md-5">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              onChange={(e) => setName(e.target.value)}
              value={name}
            />
          </div>
        </div>

        {/* ------vendor display name---------- */}
        <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Vendor Display Name
            </label>
          </div>
          <div className="col-md-5">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              onChange={(e) => setName(e.target.value)}
              value={name}
            />
          </div>
        </div>

        {/* ------vendor email ---------- */}
        <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Vendor Email
            </label>
          </div>
          <div className="col-md-5">
            <div class="input-group flex-nowrap textInput">
              <span class="input-group-text" id="addon-wrapping">
                <img src="../images/email-icon.png" alt="" srcset="" />
              </span>
              <input
                type="email"
                class="form-control "
                required
                onChange={(e) => setEmail(e.target.value)}
                value={email}
                aria-label="Username"
                aria-describedby="addon-wrapping"
              />
            </div>
          </div>
        </div>

        {/* ------vendor phone number---------- */}
        <div className="rowmt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Customer Phone
            </label>
          </div>
          <div className="col-md-5">
            <div class="input-group flex-nowrap textInput">
              <span class="input-group-text" id="addon-wrapping">
                <img src="../images/phone-icon.png" alt="" srcset="" />
              </span>
              <input
                type="number"
                class="form-control "
                required
                onChange={(e) => setPhone(e.target.value)}
                value={phone}
                aria-label="Username"
                aria-describedby="addon-wrapping"
              />
            </div>
          </div>
        </div>


{/* ----------------Tabs starting---------- */}
<div className="row my-5">
<Tabs
      defaultActiveKey="other"
      id="uncontrolled-tab-example"
      className="mb-3"
    >
        {/* -------------other details tab starting---------- */}
      <Tab eventKey="other" title="Other details" >
     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
            PAN
            </label>
          </div>
          <div className="col-md-5">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              onChange={(e) => setName(e.target.value)}
              value={name}
            />
          </div>
        </div>

   {/* ---------------------------------- */}
        <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-2 text-start">
                <label for="inputText" className="col-form-label label">
                 Currency
                </label>
              </div>
              <div className="col-md-5">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                >
                  <option value="INR">INR - Indian Rupee</option>
                  <option value="USD">USD - US Dollar</option>
                  <option value="JPY">JPY - japani yen</option>
                </select>
              </div>
            </div>

   {/* ---------------------------------- */}
            <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
            Opening Balance
            </label>
          </div>
          <div className="col-md-5">
            <div class="input-group flex-nowrap textInput">
              <span class="input-group-text" id="addon-wrapping">
               INR
              </span>
              <input
                type="email"
                class="form-control "
                required
                aria-label="Username"
                aria-describedby="addon-wrapping"
              />
            </div>
          </div>
        </div>


        
 {/* ---------------------------------- */}
 <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-2 text-start">
                <label for="inputText" className="col-form-label label">
              TDS
                </label>
              </div>
              <div className="col-md-5">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                >
                    <option value="Net-15">Commision or Brokerage [5%]</option>
                    <option value="Net-30">Dividend</option>
            
                  
                </select>
              </div>
            </div>


 {/* ---------------------------------- */}
 <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-2 text-start">
                <label for="inputText" className="col-form-label label">
                Payment Term
                </label>
              </div>
              <div className="col-md-5">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                >
                    <option value="Net-15">Net 15</option>
                    <option value="Net-30">Net 30</option>
                    <option value="Net-45">Net 45</option>
                    <option value="Net-60">Net 60</option>
                    <option value="Due end of the month" active>Due end of the month</option>
                    <option value="Due end of the next month" active>Due end of the next month</option>
                  <option value="Due on Receipt" active>Due on Receipt</option>
                  
                </select>
              </div>
            </div>

     {/* ---------------------------------- */}
 <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-2 text-start">
                <label for="inputText" className="col-form-label label">
                Portal Language
                </label>
              </div>
              <div className="col-md-5">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                >
                    <option value="English">English</option>
                    <option value="Kannada">Kannada</option>
                    <option value="Hindi">Hindi</option>
                    <option value="Gujrati">Gujrati</option>
                    <option value="Marathi" >Marathi</option>
                 
                  
                </select>
              </div>
            </div>


     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-2 text-start">
                <label for="inputText" className="col-form-label label">
                Documents
                </label>
              </div>
              <div className="col-md-5">
            
              <div class="input-group mb-3 textInput">
  <input type="file" class="form-control" id="inputGroupFile02"/>
</div>
              </div>
            </div>

      </Tab>
      {/* -------------Address tab starting---------- */}
      <Tab eventKey="address" title="Address">
        <div className="row gy-3">
            <div className="col-md-6 ">
                <div className="row text-start mb-md-3 mb-0">
                    <h6>Billing Address</h6>
                </div>

                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
              Attension
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>

     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-4 text-start">
                <label for="inputText" className="col-form-label label">
                Country/Region
                </label>
              </div>
              <div className="col-md-7">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                >
                    <option value="English">India</option>
                    <option value="Kannada">Afganistan</option>
                    <option value="Hindi">Sri Lanka</option>
                    <option value="Gujrati">Nepal</option>
                    <option value="Marathi" >China</option>
                    <option value="Marathi" >Bhutan</option>
                  
                </select>
              </div>
            </div>

{/* ---------------------------------- */}
            <div className="row mt-md-2 mt-1 g-md-3 g-1">
                  <div className="col-md-4 text-start">
                    <label for="inputText" className="col-form-label label">
                     Address
                    </label>
                  </div>
                  <div className="col-md-7">
                    <div className="form-floating">
                      <textarea
                        className="form-control"
                        placeholder="Street 1"
                        id="floatingTextarea2"
                        style={{ height: "70px" }}
                      ></textarea>
                    </div>
                  </div>
                </div>



                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             City
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>



     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-4 text-start">
                <label for="inputText" className="col-form-label label">
              State
                </label>
              </div>
              <div className="col-md-7">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                >
                    <option value="English">Arunachal Pradesh</option>
                    <option value="Kannada">Telangana</option>
                    <option value="Hindi">Gujrat</option>
                    <option value="Gujrati">Maharashtra</option>
                    <option value="Marathi" >Karnataka</option>
                    <option value="Marathi" >Madhyapradesh</option>
                    <option value="Marathi" >Chhattisgrah</option>
                  
                </select>
              </div>
            </div>



                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             PinCode
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>


                  {/* ---------------------------------- */}
                  <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             Phone
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>


                  {/* ---------------------------------- */}
                  <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             Fax Number
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>

            </div>
            <div className="col-md-6 ">
                <div className="row text-start mb-3">
                    <h6>Shipping Address</h6>
                </div>

                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
              Attension
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>

     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-4 text-start">
                <label for="inputText" className="col-form-label label">
                Country/Region
                </label>
              </div>
              <div className="col-md-7">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                >
                    <option value="English">India</option>
                    <option value="Kannada">Afganistan</option>
                    <option value="Hindi">Sri Lanka</option>
                    <option value="Gujrati">Nepal</option>
                    <option value="Marathi" >China</option>
                    <option value="Marathi" >Bhutan</option>
                  
                </select>
              </div>
            </div>

{/* ---------------------------------- */}
            <div className="row mt-3">
                  <div className="col-md-4 text-start">
                    <label for="inputText" className="col-form-label label">
                     Address
                    </label>
                  </div>
                  <div className="col-md-7">
                    <div className="form-floating">
                      <textarea
                        className="form-control"
                        placeholder="Street 1"
                        id="floatingTextarea2"
                        style={{ height: "70px" }}
                      ></textarea>
                    </div>
                  </div>
                </div>



                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             City
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>



     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-4 text-start">
                <label for="inputText" className="col-form-label label">
              State
                </label>
              </div>
              <div className="col-md-7">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                >
                    <option value="English">Arunachal Pradesh</option>
                    <option value="Kannada">Telangana</option>
                    <option value="Hindi">Gujrat</option>
                    <option value="Gujrati">Maharashtra</option>
                    <option value="Marathi" >Karnataka</option>
                    <option value="Marathi" >Madhyapradesh</option>
                    <option value="Marathi" >Chhattisgrah</option>
                  
                </select>
              </div>
            </div>



                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             PinCode
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>


                  {/* ---------------------------------- */}
                  <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             Phone
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>


                  {/* ---------------------------------- */}
                  <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             Fax Number
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required

            />
          </div>
        </div>

            </div>
        </div>

      </Tab>

{/* ------------contact person tab starting---------- */}

      <Tab eventKey="contactperson" title="Contact Person" >
      <div className="row overflow-auto">
        <div className="col-md-12">
<table class="table">
  <thead>
    <tr>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email Address</th>
      <th scope="col">Work Phone</th>
      <th scope="col">Designation</th>
      <th scope="col">Department</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
              required
        style={{width:'180px'}}
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
              required
        style={{width:'180px'}}
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
              required
        style={{width:'180px'}}
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
              required
        style={{width:'180px'}}
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
              required
        style={{width:'180px'}}
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
              required
        style={{width:'180px'}}
            />
      </td>
    </tr>
    
  </tbody>
</table>
        </div>
      </div>
      </Tab>
      <Tab eventKey="remarks" title="Remarks" >
     <div className="row">
        Remarks (for internal use)
        <br />
        <div className="col-md-7">
        
                    <div className="form-floating">
                      <textarea
                        className="form-control"
                        placeholder="Street 1"
                        id="floatingTextarea2"
                        style={{ height: "70px" }}
                      ></textarea>
                    </div>
                  </div>
     </div>
      </Tab>

    </Tabs>
    <div className="row fixed-bottom">
<div className="col-md-6 col-6">
                  <button
                    type="submit"
                    class="btn btn-primary float-end"
                
                  >
                    Save
                  </button>
                </div>
                <div className="col-md-6 col-6">
                  <button type="button" class="btn btn-outline-info float-start">
                    Cancel
                  </button>
                </div>
</div>
</div>


      </form>

    </div>
  )
}

export default Vendors