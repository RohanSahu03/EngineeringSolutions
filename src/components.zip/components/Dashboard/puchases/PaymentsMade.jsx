import React, { useState, useRef } from "react";
import Button from "react-bootstrap/Button";
import Overlay from "react-bootstrap/Overlay";
import { TiArrowSortedDown } from "react-icons/ti";
import { TiPlus } from "react-icons/ti";
import "../../../css/dashboard/items.css";
import Offcanvas from "react-bootstrap/Offcanvas";
import { MdDeleteForever } from "react-icons/md";
import Dropdown from "react-bootstrap/Dropdown";

import { PiNewspaperClippingFill } from "react-icons/pi";

import { AiFillPlusCircle } from "react-icons/ai";
import { RxCross1 } from "react-icons/rx";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { IoSearch } from "react-icons/io5";

function PaymentsMade() {
  const [show, setShow] = useState(false);
  const [product, setProducts] = useState([]);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [show1, setShow1] = useState(false);
  const target1 = useRef(null);

  const [show2, setShow2] = useState(false);
  const target2 = useRef(null);

  const [type, setType] = useState("");
  const [name, setName] = useState("");
  const [unit, setUnit] = useState("");
  const [cost, setCost] = useState("");
  const [salesaccount, setSalesAccount] = useState("");
  const [desc, setDesc] = useState("");
  const [purchasecost, setPurchaseCost] = useState("");
  const [purchaseaccount, setPurchaseAccount] = useState("");
  const [purchasedisc, setPurchaseDisc] = useState("");

  const handleRadioChange = (event) => {
    setType(event.target.value);
  };

  const handleUnit = (event) => {
    setUnit(event.target.value);
  };

  const handleSalesAccount = (event) => {
    setSalesAccount(event.target.value);
  };

  const handlePurchaseAccount = (event) => {
    setPurchaseAccount(event.target.value);
  };

  const [startDate, setStartDate] = useState(new Date());
  const [rows, setRows] = useState([]);

  const addRow = () => {
    const newRow = { id: rows.length + 1, data: 'New Row' };
    setRows([...rows, newRow]);
};


  const handleFormData = (e) => {
    e.preventDefault();
    const data = {
      id: `UNIT${Math.floor(Math.random() * 99999999999)}`,
      type,
      name,
      unit,
      cost,
      salesaccount,
      desc,
      purchasecost,
      purchaseaccount,
      purchasedisc,
    };
    setProducts([...product, data]);
    alert("item saved..");
  };

  const deleteProduct = (id) => {
    setProducts([...product.filter((item) => item.id !== id)]);
  };

  const sortByName=()=>{
    setProducts([...product.sort((a,b)=>a.name.localeCompare(b.name))]);
  }
  const sortByRate=()=>{
    setProducts([...product.sort((a,b)=>a.cost-b.cost)]);
  }

  const sortByPurchaseRate=()=>{
    setProducts([...product.sort((a,b)=>a.purchasecost-b.purchasecost)]);
  }

  return (
    <div>
      <div className="row border py-3 d-flex ">
        <div className="col-md-6 col-6">
          <Button
            variant="transparent"
            className="float-start"
            ref={target1}
            onClick={() => setShow1(!show1)}
          >
            Unpaid Bills <TiArrowSortedDown />
          </Button>
          <Overlay target={target1.current} show={show1} placement="bottom">
            {({
              placement: _placement,
              arrowProps: _arrowProps,
              show: _show,
              popper: _popper,
              hasDoneInitialMeasure: _hasDoneInitialMeasure,
              ...props
            }) => (
              <div
                {...props}
                style={{
                  position: "absolute",
                  backgroundColor: "",
                  padding: "2px 10px",
                  color: "black",
                  borderRadius: 3,
                  ...props.style,
                }}
              >
                <ul class="list-group">
                  <li class="list-group-item list-group-item-action">Open</li>
                  <li class="list-group-item list-group-item-action">
                    Draft
                  </li>
                  <li class="list-group-item list-group-item-action">OverDue</li>
                  <li class="list-group-item list-group-item-action">
                    Pending Approval
                  </li>
                  <li class="list-group-item list-group-item-action">
                   Unpaid
                  </li>
                  <li class="list-group-item list-group-item-action">
                   Partially paid
                  </li>
                </ul>
              </div>
            )}
          </Overlay>
        </div>

        <div className="col-md-6 col-6 d-flex justify-content-end">

          {/* < BsThreeDotsVertical className='menuDot'/> */}
        <div className="buttons">
        <button
            type="button"
            className="btn btn-primary d-inline"
            onClick={handleShow}
          >
            <TiPlus /> New
          </button>
        <Dropdown className="mx-3">
            <Dropdown.Toggle variant="transparent outline btn-outline-primary" id="dropdown-basic">
         Sort
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item onClick={sortByName}>Name</Dropdown.Item>
              <Dropdown.Item onClick={sortByRate}>Rate</Dropdown.Item>
              <Dropdown.Item  onClick={sortByPurchaseRate}>Purchase Rate</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
        </div>
      </div>

      <div className="row overflow-auto">
        <div className="col-md-12">
          <table class="table">
            <thead class="thead-light">
              <tr>
                <th scope="col">Date</th>
                <th scope="col">Bill#</th>
                <th scope="col">Reference Number</th>
                <th scope="col">Vendor Name</th>
                <th scope="col">Status</th>
                <th scope="col">Due Date</th>
                <th scope="col">Amount</th>
                <th scope="col">Balance Due</th>
              </tr>
            </thead>
            {
              product.length!==0 ? (
                <tbody >
                {product.map((item) => {
                  return (
                    <tr key={item.id}>
                      <td>{item.name}</td>
                      <td>{item.desc}</td>
                      <td>{item.purchasedisc}</td>
                      <td>{item.cost}</td>
                      <td>{item.purchasecost}</td>
                      <td>{item.unit}</td>
                      <td>
                        <MdDeleteForever onClick={() => deleteProduct(item.id)} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              ):(
                <div className="container ">
     <div className="row mt-4   ">
      <div className="col-md-12 ">

      <h6>There are no unpaid bills</h6>
      </div>
     
          </div>
                </div>
           
              )
            }
          
          </table>
        </div>
      </div>

      {/* Off-Canvas--------------------------- */}

      <Offcanvas
        show={show}
        onHide={handleClose}
        placement="end"
        style={{ width: "1000px",backgroundColor:'white' }}
      >
        <Offcanvas.Header closeButton>
        </Offcanvas.Header>
        <Offcanvas.Body>
        <div className="row border-bottom py-2 text-start d-flex ">
        <h3><PiNewspaperClippingFill/>&nbsp;&nbsp;New Bill</h3>
      </div>
              <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Vendor Name*
          </label>
        </div>
        <div className="col-md-5 ">
        <div class="input-group mb-3 textInput">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="select customer"
                        aria-label="Recipient's username"
                        aria-describedby="button-addon2"
                      />
                      <button
                        class="btn btn-primary"
                        type="button"
                        id="button-addon2"
                      >
                        {" "}
                        <IoSearch style={{ fontSize: "22px" }} />
                      </button>
                    </div>
        </div>
      </div>

      {/* ------sales ordder---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Bill#*
          </label>
        </div>
        <div className="col-md-5">
          <input
            type="text"
            id="inputText"
            className="form-control textInput"
            required
        
          />
        </div>
      </div>


            {/* ------sales ordder---------- */}
            <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Order Number
          </label>
        </div>
        <div className="col-md-5">
          <input
            type="text"
            id="inputText"
            className="form-control textInput"
        
          />
        </div>
      </div>


      {/* ------sales order date---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
          Bill Date*
          </label>
        </div>
        <div className="col-md-5  text-start">
          <DatePicker
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            className="textInput"
            style={{ outline: "none" }}
            required
          />
        </div>
      </div>

 {/* ------sales order date---------- */}
 <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Due Date
          </label>
        </div>
        <div className="col-md-5  text-start">
          <DatePicker
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            className="textInput"
            style={{ outline: "none" }}
            required
          />
        </div>
      </div>


      {/* -------------payment term--------------------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
          Payment Terms
          </label>
        </div>
        <div className="col-md-5">
          <select
            className="form-select textInput"
            id="inputGroupSelect03"
            aria-label="Example select with button addon"
            placeholder='choose a proper challan type'
          >
            <option value="Net-15">Supply of Liquid gas</option>
            <option value="Net-30">Job work</option>
            <option value="Net-45">Other</option>
          </select>
        </div>
      </div>

   
            {/* ------sales ordder---------- */}
            <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Subject
          </label>
        </div>
        <div className="col-md-5">
          <input
            type="text"
            id="inputText"
            className="form-control textInput"
        placeholder='enter a subject within 250 character'
          />
        </div>
      </div>

{/* --------------item table------------- */}
      <div className="row mt-3  text-start" >
        <h5 className="py-2 bg-secondary text-light">Item Table</h5>
      </div>

      <div className="row mt-1 overflow-auto">
        <table class="table table-striped">
          <thead className="thead-dark">
            <tr>
              <th scope="col">item details</th>
              <th scope="col">account</th>
              <th scope="col">quantity</th>
              <th scope="col">rate</th>
              <th scope="col">customer details</th>
              <th scope="col">ammount</th>
            </tr>
          </thead>
          <tbody>
            {/* --------------first row--------------- */}
            <tr>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                  placeholder="type to select an item"
                />
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                  value="1.00"
                />
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                  value="0.00"
                />
              </td>
              <td>
             
                    <input
                      type="text"
                      id="inputText"
                      className="form-control textInput"
                      style={{ width: "150px" }}
                      value="0.00"
                    />
          
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                />
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                />
              </td>
              <td>
                <RxCross1 />
              </td>
            </tr>

            {/* --------------dynamic row--------------- */}

            {rows.map((row) => (
              <tr key={row.id}>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                    placeholder="type to select an item"
                  />
                </td>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                    value="1.00"
                  />
                </td>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                    value="0.00"
                  />
                </td>
                <td>
                 
                      <input
                        type="text"
                        id="inputText"
                        className="form-control textInput"
                        style={{ width: "150px" }}
                        value="0.00"
                      />
                
                </td>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                  />
                </td>

                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                  />
                </td>

                <td>
                  <RxCross1 />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ---------button----------    */}
      <div className="row">
        <div className="col-md-2">
          <Button variant="secondary" size="sm" onClick={addRow}>
            <AiFillPlusCircle
              data-bs-container="body"
              data-bs-toggle="popover"
              data-bs-placement="bottom"
              data-bs-content="Bottom popover"
            />
            &nbsp; add new row
          </Button>
        </div>
   
        <div className="col-md-6 p-md-5 p-2 mt-1" style={{ background: "aliceblue",float:'right' }}>
          <div className="row">
            <div className="col-md-4 col-4 text-start">
              <h6>subtotal</h6>
            </div>
            <div className="col-md-4 col-4 text-end"></div>
            <div className="col-md-4 col-4 text-center">0.00</div>
          </div>


          <div className="row mt-3">
    <div className="col-md-4 col-4 text-start">
   <small>Shipping Charges</small>
    </div>
    <div className="col-md-4 col-4">
    <input
              type="text"
              id="inputText"
              className="form-control textInput formInput"
            
            
            />
    </div>
    <div className="col-md-4 col-4 text-center">
    <p>0.00</p>
    </div>
  </div>



          <div className="row mt-3">
    <div className="col-md-4 col-4">
    <div className="row">
                  <div className="col-md-6 col-6">
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        name="flexRadioDefault"
                        id="flexRadioDefault1"
                        type="radio"
                        value="TDS"
                    
                      />
                      <label class="form-check-label" for="flexRadioDefault1">
                        TDS
                      </label>
                    </div>
                  </div>
                  <div className="col-md-6 col-6">
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        name="flexRadioDefault"
                        id="flexRadioDefault1"
                        value="TCS"
                
                      />
                      <label class="form-check-label" for="flexRadioDefault1">
                       TCS
                      </label>
                    </div>
                  </div>
                </div>
    </div>
    <div className="col-md-4 col-4">
    <select
                  className="form-select formInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  style={{width:'150px'}}
                >
                  <option value="INR">select a tax</option>
                  <option value="USD"></option>
                  <option value="JPY"></option>
                </select>
    </div>
    <div className="col-md-4 col-4 text-center">
    <p>0.00</p>
    </div>
  </div>


          <div className="row mt-3">
            <div className="col-md-4 col-4">
              <input
                type="text"
                id="inputText"
                className="form-control textInput formInput"
                
              />
            </div>
            <div className="col-md-4 col-4">
              <input
                type="text"
                id="inputText"
                className="form-control textInput formInput"
        
              />
            </div>
            <div className="col-md-4 col-4 text-center">
              <p>0.00</p>
            </div>
          </div>


          <div className="row mt-2 border-top">
            <div className="col-md-6 col-6">
              <h4>Total (₹)</h4>
            </div>
            <div className="col-md-6 col-6 text-center">
              <h4>0.00</h4>
            </div>
          </div>

  


        </div>
        <div className="row py-2">
<div className="col-md-6 col-6">
                  <button
                    type="submit"
                    class="btn btn-primary float-end"
                
                  >
                    Save
                  </button>
                </div>
                <div className="col-md-6 col-6">
                  <button type="button" class="btn btn-outline-info float-start">
                    Cancel
                  </button>
                </div>
</div>
      </div>
        </Offcanvas.Body>
      </Offcanvas>

      {/* off-canvas End ------------------ */}
    </div>
  );
}

export default PaymentsMade;
