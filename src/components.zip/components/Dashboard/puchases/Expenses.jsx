import React,{useState} from 'react'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import { IoSearch } from "react-icons/io5";

function Expenses() {
    const [startDate, setStartDate] = useState(new Date());
  return (
    <div>
        <Tabs
      defaultActiveKey="recordexpenses"
      id="uncontrolled-tab-example"
      className="mb-3 mt-3"
    >
      <Tab eventKey="recordexpenses" title="Record Expense">
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
          Date*
          </label>
        </div>
        <div className="col-md-5  text-start">
        <DatePicker
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            className="textInput"
            style={{ outline: "none" }}
            required
          />
        </div>
      </div>

      {/* ------sales ordder---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
           Expense Account*
          </label>
        </div>
        <div className="col-md-5">
        <select
            className="form-select textInput"
            id="inputGroupSelect03"
            aria-label="Example select with button addon"
            placeholder='choose a proper challan type'
            required
          >
            <option value="Net-15">Contact Assets</option>
            <option value="Net-30">Labor</option>
            <option value="Net-45">Job Costing</option>
          </select>
        </div>
      </div>

      {/* ------refrence---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
           Ammount*
          </label>
        </div>
        <div className="col-md-5">
        <div class="input-group flex-nowrap textInput">
              <span class="input-group-text" id="addon-wrapping">
                INR
              </span>
              <input
                type="number"
                class="form-control "
                required
                aria-label="Username"
                aria-describedby="addon-wrapping"
              />
            </div>
        </div>
      </div>



      {/* -------------payment term--------------------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
         Paid Through*
          </label>
        </div>
        <div className="col-md-5">
          <select
            className="form-select textInput"
            id="inputGroupSelect03"
            aria-label="Example select with button addon"
            placeholder='select an account'
          >
            <option value="Net-15">Advance Tax</option>
            <option value="Net-30">Job work</option>
            <option value="Net-45">Other</option>
          </select>
        </div>
      </div>


      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
             Vendor
            </label>
          </div>
          <div className="col-md-5 ">
            <div className="row">
              <div className="col-md-8 ">
              <div class="input-group mb-3 textInput">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="select customer"
                        aria-label="Recipient's username"
                        aria-describedby="button-addon2"
                      />
                      <button
                        class="btn btn-primary"
                        type="button"
                        id="button-addon2"
                      >
                        {" "}
                        <IoSearch style={{ fontSize: "22px" }} />
                      </button>
                    </div>
              </div>
           
            </div>
         

          
          </div>
        </div>


      {/* -------------payment term--------------------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
         Invoice#
          </label>
        </div>
        <div className="col-md-5">
        <input
            type="text"
            id="inputText"
            className="form-control textInput"
            required
            value="DC-00001"
          />
        </div>
      </div>

{/* ---------------------------------- */}
<div className="row mt-3">
                  <div className="col-md-2 text-start">
                    <label for="inputText" className="col-form-label label">
                   Notes
                    </label>
                  </div>
                  <div className="col-md-5">
                    <div className="form-floating">
                      <textarea
                        className="form-control"
                        placeholder="Max 500 characters"
                        id="floatingTextarea2"
                        style={{ height: "60px",width:'300px' }}
                      ></textarea>
                    </div>
                  </div>
                </div>
 {/* -------------------------------- */}
                <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
             Customer Name
            </label>
          </div>
          <div className="col-md-5 ">
            <div className="row">
              <div className="col-md-8 ">
              <div class="input-group mb-3 textInput">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="select customer"
                        aria-label="Recipient's username"
                        aria-describedby="button-addon2"
                      />
                      <button
                        class="btn btn-primary"
                        type="button"
                        id="button-addon2"
                      >
                        {" "}
                        <IoSearch style={{ fontSize: "22px" }} />
                      </button>
                    </div>
                    </div>
            </div>
          </div>
        </div>


        <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
        Upload Receipt
          </label>
        </div>
        <div className="col-md-5">
        <input type="file" class="form-control textInput" id="inputGroupFile02"/>
        </div>
      </div>

      <div className="row mt-3">
<div className="col-md-6 col-6">
                  <button
                    type="submit"
                    class="btn btn-primary float-end"
                
                  >
                    Save
                  </button>
                </div>
                <div className="col-md-6 col-6">
                  <button type="button" class="btn btn-outline-info float-start">
                    Cancel
                  </button>
                </div>
</div>

      </Tab>
      <Tab eventKey="recordmileage" title="Record Mileage">
        Tab content for Profile
      </Tab>
      <Tab eventKey="contact" title="Contact" disabled>
        Tab content for Contact
      </Tab>
    </Tabs>
    </div>
  )
}

export default Expenses