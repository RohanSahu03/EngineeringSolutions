import React, { useState, useRef } from "react";
import Button from "react-bootstrap/Button";
import Overlay from "react-bootstrap/Overlay";
import { TiArrowSortedDown } from "react-icons/ti";
import { TiPlus } from "react-icons/ti";
import { BsThreeDotsVertical } from "react-icons/bs";
import "../../css/dashboard/items.css";
import Offcanvas from "react-bootstrap/Offcanvas";
import { MdDeleteForever } from "react-icons/md";
import Dropdown from "react-bootstrap/Dropdown";

function Items() {
  const [show, setShow] = useState(false);
  const [product, setProducts] = useState([]);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [show1, setShow1] = useState(false);
  const target1 = useRef(null);

  const [show2, setShow2] = useState(false);
  const target2 = useRef(null);

  const [type, setType] = useState("");
  const [name, setName] = useState("");
  const [unit, setUnit] = useState("");
  const [cost, setCost] = useState("");
  const [salesaccount, setSalesAccount] = useState("");
  const [desc, setDesc] = useState("");
  const [purchasecost, setPurchaseCost] = useState("");
  const [purchaseaccount, setPurchaseAccount] = useState("");
  const [purchasedisc, setPurchaseDisc] = useState("");

  const handleRadioChange = (event) => {
    setType(event.target.value);
  };

  const handleUnit = (event) => {
    setUnit(event.target.value);
  };

  const handleSalesAccount = (event) => {
    setSalesAccount(event.target.value);
  };

  const handlePurchaseAccount = (event) => {
    setPurchaseAccount(event.target.value);
  };

  const handleFormData = (e) => {
    e.preventDefault();
    const data = {
      id: `UNIT${Math.floor(Math.random() * 99999999999)}`,
      type,
      name,
      unit,
      cost,
      salesaccount,
      desc,
      purchasecost,
      purchaseaccount,
      purchasedisc,
    };
    setProducts([...product, data]);
    alert("item saved..");
  };

  const deleteProduct = (id) => {
    setProducts([...product.filter((item) => item.id !== id)]);
  };

  const sortByName=()=>{
    setProducts([...product.sort((a,b)=>a.name.localeCompare(b.name))]);
  }
  const sortByRate=()=>{
    setProducts([...product.sort((a,b)=>a.cost-b.cost)]);
  }

  const sortByPurchaseRate=()=>{
    setProducts([...product.sort((a,b)=>a.purchasecost-b.purchasecost)]);
  }

  return (
    <div>
      <div className="row border py-3 d-flex ">
        <div className="col-md-6 col-6">
          <Button
            variant="transparent"
            className="float-start"
            ref={target1}
            onClick={() => setShow1(!show1)}
          >
            All Items <TiArrowSortedDown />
          </Button>
          <Overlay target={target1.current} show={show1} placement="bottom">
            {({
              placement: _placement,
              arrowProps: _arrowProps,
              show: _show,
              popper: _popper,
              hasDoneInitialMeasure: _hasDoneInitialMeasure,
              ...props
            }) => (
              <div
                {...props}
                style={{
                  position: "absolute",
                  backgroundColor: "",
                  padding: "2px 10px",
                  color: "black",
                  borderRadius: 3,
                  ...props.style,
                }}
              >
                <ul class="list-group">
                  <li class="list-group-item list-group-item-action">Active</li>
                  <li class="list-group-item list-group-item-action">
                    Inactive
                  </li>
                  <li class="list-group-item list-group-item-action">Sales</li>
                  <li class="list-group-item list-group-item-action">
                    Purchase
                  </li>
                </ul>
              </div>
            )}
          </Overlay>
        </div>

        <div className="col-md-6 col-6 d-flex justify-content-end">

          {/* < BsThreeDotsVertical className='menuDot'/> */}
        <div className="buttons">
        <button
            type="button"
            className="btn btn-primary d-inline"
            onClick={handleShow}
          >
            <TiPlus /> New
          </button>
        <Dropdown className="mx-3">
            <Dropdown.Toggle variant="transparent outline btn-outline-primary" id="dropdown-basic">
         Sort
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item onClick={sortByName}>Name</Dropdown.Item>
              <Dropdown.Item onClick={sortByRate}>Rate</Dropdown.Item>
              <Dropdown.Item  onClick={sortByPurchaseRate}>Purchase Rate</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
        </div>
      </div>

      <div className="row overflow-auto">
        <div className="col-md-12">
          <table class="table">
            <thead class="thead-light">
              <tr>
                <th scope="col">Name</th>
                <th scope="col">Description</th>
                <th scope="col">Purchase Description</th>
                <th scope="col">Rate</th>
                <th scope="col">Purchase Rate</th>
                <th scope="col">Usage unit</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            { product.length!==0 ? (
                <tbody>
                {product.map((item) => {
                  return (
                    <tr key={item.id}>
                      <td>{item.name}</td>
                      <td>{item.desc}</td>
                      <td>{item.purchasedisc}</td>
                      <td>{item.cost}</td>
                      <td>{item.purchasecost}</td>
                      <td>{item.unit}</td>
                      <td>
                        <MdDeleteForever onClick={() => deleteProduct(item.id)} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              ):(
                <div className="container ">
     <div className="row mt-4 ">
      <div className="col-md-12 ">
      <img src="../images/emptybox.jpg" alt="" srcset="" style={{width:'200px',height:'200px',opacity:'0.4'}}/>
      <h6>There are no inactive items.</h6>
      </div>
     
          </div>
                </div>
           
              )
            }
          </table>
          
       
        </div>
      </div>

      {/* Off-Canvas--------------------------- */}

      <Offcanvas
        show={show}
        onHide={handleClose}
        placement="end"
        style={{ width: "1000px",backgroundColor:'white' }}
      >
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>New Item</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <form class="row g-3 needs-validation" novalidate>
            <div className="row g-3 align-items-center">
              <div className="col-md-2">
                <label for="inputText" className="col-form-label label">
                  Type
                </label>
              </div>
              <div className="col-md-5">
                <div className="row">
                  <div className="col-md-6">
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        name="flexRadioDefault"
                        id="flexRadioDefault1"
                        type="radio"
                        value="goods"
                        checked={type === "goods"}
                        onChange={handleRadioChange}
                      />
                      <label class="form-check-label" for="flexRadioDefault1">
                        Goods
                      </label>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        name="flexRadioDefault"
                        id="flexRadioDefault1"
                        value="service"
                        checked={type === "service"}
                        onChange={handleRadioChange}
                      />
                      <label class="form-check-label" for="flexRadioDefault1">
                        Service
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-2 g-3 align-items-center">
              <div className="col-md-2">
                <label for="inputText" className="col-form-label label">
                  Name*
                </label>
              </div>
              <div className="col-md-5">
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  required
                  onChange={(e) => setName(e.target.value)}
                  value={name}
                />
              </div>
            </div>

            <div className="row g-3 mt-2 align-items-center">
              <div className="col-md-2">
                <label for="inputText" className="col-form-label label">
                  Unit
                </label>
              </div>
              <div className="col-md-5">
                <select
                  className="form-select textInput"
                  value={unit}
                  onChange={handleUnit}
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                >
                  <option value=""></option>
                  <option value="Box">Box - box</option>
                  <option value="cm">CMS- CM</option>
                  <option value="doz">DOZ - doz</option>
                  <option value="ft">FTS - ft</option>
                  <option value="gm">GMS - gm</option>
                  <option value="in">INC - in</option>
                  <option value="kg">KGS - kg</option>
                </select>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-6">
                <h6>Sales Information</h6>
                <div className="row mt-3">
                  <div className="col-md-3">
                    <label for="inputText" className="col-form-label label">
                      Cost price*
                    </label>
                  </div>
                  <div className="col-md-8 ">
                    <div class="input-group mb-3">
                      <span class="input-group-text" id="basic-addon1">
                        INR
                      </span>
                      <input
                        type="number"
                        class="form-control"
                        aria-label="Username"
                        value={cost}
                        aria-describedby="basic-addon1"
                        onChange={(e) => setCost(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-3">
                    <label for="inputText" className="col-form-label label">
                      Account*
                    </label>
                  </div>
                  <div className="col-md-8">
                    <select
                      className="form-select textInput"
                      id="inputGroupSelect03"
                      value={salesaccount}
                      onChange={handleSalesAccount}
                      aria-label="Example select with button addon"
                      required
                    >
                      <option selected>Sales</option>
                      <option value="1">Discount</option>
                      <option value="2">General income</option>
                      <option value="3">Interest income</option>
                      <option value="3">Late fee income</option>
                    </select>
                  </div>
                </div>

                <div className="row mt-3">
                  <div className="col-md-3">
                    <label for="inputText" className="col-form-label label">
                      Description
                    </label>
                  </div>
                  <div className="col-md-8">
                    <div className="form-floating">
                      <textarea
                        className="form-control"
                        value={desc}
                        onChange={(e) => setDesc(e.target.value)}
                        placeholder="Leave a comment here"
                        id="floatingTextarea2"
                        style={{ height: "70px" }}
                      ></textarea>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-6 g-3">
                <h6>Purchase Information</h6>
                <div className="row mt-3">
                  <div className="col-md-3">
                    <label for="inputText" className="col-form-label label">
                      Cost price*
                    </label>
                  </div>
                  <div className="col-md-8 ">
                    <div class="input-group mb-3">
                      <span class="input-group-text" id="basic-addon1">
                        INR
                      </span>
                      <input
                        type="number"
                        class="form-control"
                        value={purchasecost}
                        onChange={(e) => setPurchaseCost(e.target.value)}
                        aria-label="Username"
                        aria-describedby="basic-addon1"
                      />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-3">
                    <label for="inputText" className="col-form-label label">
                      Account*
                    </label>
                  </div>
                  <div className="col-md-8">
                    <select
                      className="form-select textInput"
                      id="inputGroupSelect03"
                      value={purchaseaccount}
                      onChange={handlePurchaseAccount}
                      aria-label="Example select with button addon"
                    >
                      <option disabled>
                        {" "}
                        <b>Expenses</b>
                      </option>
                      <option value="2">Advertising & Marketing</option>
                      <option value="3">Automobile Expenses</option>
                      <option value="3">Bed Debt</option>
                      <option value="3">Bank fee & Charges</option>
                      <option value="3">Contract Assets</option>
                    </select>
                  </div>
                </div>

                <div className="row mt-3">
                  <div className="col-md-3">
                    <label for="inputText" className="col-form-label label">
                      Description
                    </label>
                  </div>
                  <div className="col-md-8">
                    <div className="form-floating">
                      <textarea
                        className="form-control"
                        value={purchasedisc}
                        onChange={(e) => setPurchaseDisc(e.target.value)}
                        placeholder="Leave a comment here"
                        id="floatingTextarea2"
                        style={{ height: "70px" }}
                      ></textarea>
                    </div>
                  </div>
                </div>

                <div className="row mt-3">
                  <div className="col-md-3">
                    <label for="inputText" className="col-form-label label">
                      Preffered Vendor
                    </label>
                  </div>
                  <div className="col-md-8">
                    <select
                      className="form-select textInput"
                      id="inputGroupSelect03"
                      aria-label="Example select with button addon"
                    ></select>
                  </div>
                </div>
              </div>

              <div className="row mt-5">
                <div className="col-md-1 col-2">
                  <button
                    type="submit"
                    class="btn btn-primary"
                    onClick={handleFormData}
                  >
                    Save
                  </button>
                </div>
                <div className="col-md-1 col-2">
                  <button type="button" class="btn btn-outline-info">
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </form>
        </Offcanvas.Body>
      </Offcanvas>

      {/* off-canvas End ------------------ */}
    </div>
  );
}

export default Items;
