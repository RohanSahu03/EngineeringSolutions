import React,{useState} from 'react'
import { IoSearch } from "react-icons/io5";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../css/dashboard/quotes.css'

function Quotes() {
  const [startDate, setStartDate] = useState(new Date());
  const [rows, setRows] = useState([]);

  const addRow = () => {
    const newRow = { id: rows.length + 1, data: 'New Row' };
    setRows([...rows, newRow]);
};

  return (
    <div>
              <div className="row border-bottom py-2 text-start d-flex ">
          <h3>New Quotes</h3>
        </div>
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Customer Name*
          </label>
        </div>
        <div className="col-md-5 ">
        <div class="input-group mb-3 textInput">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="select customer"
                        aria-label="Recipient's username"
                        aria-describedby="button-addon2"
                      />
                      <button
                        class="btn btn-primary"
                        type="button"
                        id="button-addon2"
                      >
                        {" "}
                        <IoSearch style={{ fontSize: "22px" }} />
                      </button>
                    </div>
        </div>
      </div>


                {/* ------quote---------- */}
                <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Quote*
            </label>
          </div>
          <div className="col-md-5">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value='QT-00001'
            />
          </div>
        </div>


            {/* ------refrence---------- */}
            <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
             Reference#
            </label>
          </div>
          <div className="col-md-5">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
  
            />
          </div>
        </div>

            {/* ------quote date---------- */}
            <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
            Quote Date*
            </label>
          </div>
          <div className="col-md-5  text-start">
          <DatePicker selected={startDate} onChange={(date) => setStartDate(date)}  className='textInput' style={{outline:'none'}} required/>
          </div>
        </div>

           {/* ------Expiry date---------- */}
           <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center border-bottom pb-2">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
            Expiry Date*
            </label>
          </div>
          <div className="col-md-5  text-start">
          <DatePicker selected={startDate} onChange={(date) => setStartDate(date)}  className='textInput' style={{outline:'none'}}/>
          </div>
        </div>

{/* ------------salesperson--------- */}
<div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Sales Person
          </label>
        </div>
        <div className="col-md-5 ">
        <div class="input-group mb-3 textInput">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="select customer"
                        aria-label="Recipient's username"
                        aria-describedby="button-addon2"
                      />
                      <button
                        class="btn btn-primary"
                        type="button"
                        id="button-addon2"
                      >
                        {" "}
                        <IoSearch style={{ fontSize: "22px" }} />
                      </button>
                    </div>
        </div>
      </div>



    </div>
  )
}

export default Quotes