import React, { useState } from "react";
import { IoSearch } from "react-icons/io5";
import { LuShoppingCart } from "react-icons/lu";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Dropdown from 'react-bootstrap/Dropdown';
import Button from 'react-bootstrap/Button';
import { AiFillPlusCircle } from "react-icons/ai";
import { RxCross1 } from "react-icons/rx";


function DeliveryChallan() {
    const [startDate, setStartDate] = useState(new Date());
    const [rows, setRows] = useState([]);
  
    const addRow = () => {
      const newRow = { id: rows.length + 1, data: 'New Row' };
      setRows([...rows, newRow]);
  };
  return (
    <div>
              <div className="row border-bottom py-2 text-start d-flex ">
        <h3>
           New Delivery Challan
        </h3>
      </div>
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center" style={{width:'100%'}}>
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Customer Name*
          </label>
        </div>
        <div className="col-md-5 ">
          <div className="row">
          <div class="input-group mb-md-3 mb-0 textInput">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="select customer"
                        aria-label="Recipient's username"
                        aria-describedby="button-addon2"
                      />
                      <button
                        class="btn btn-primary"
                        type="button"
                        id="button-addon2"
                      >
                        {" "}
                        <IoSearch style={{ fontSize: "22px" }} />
                      </button>
                    </div>
          </div>
        </div>
      </div>

      {/* ------sales ordder---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Delivery Challan*
          </label>
        </div>
        <div className="col-md-5">
          <input
            type="text"
            id="inputText"
            className="form-control textInput"
            required
            value="DC-00001"
          />
        </div>
      </div>

      {/* ------refrence---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Reference#
          </label>
        </div>
        <div className="col-md-5">
          <input
            type="text"
            id="inputText"
            className="form-control textInput"
          />
        </div>
      </div>

      {/* ------sales order date---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Delivery Challan Date*
          </label>
        </div>
        <div className="col-md-5  text-start">
          <DatePicker
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            className="textInput"
            style={{ outline: "none" }}
            required
          />
        </div>
      </div>


      {/* -------------payment term--------------------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 pb-4 border-bottom align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
           Challan Type
          </label>
        </div>
        <div className="col-md-5">
          <select
            className="form-select textInput"
            id="inputGroupSelect03"
            aria-label="Example select with button addon"
            placeholder='choose a proper challan type'
          >
            <option value="Net-15">Supply of Liquid gas</option>
            <option value="Net-30">Job work</option>
            <option value="Net-45">Other</option>
          </select>
        </div>
      </div>

   

{/* --------------item table------------- */}
      <div className="row mt-3 text-start">
        <h5 className="py-2 bg-secondary text-light">Item Table</h5>
      </div>

      <div className="row mt-1 overflow-auto">
        <table class="table table-striped">
          <thead className="thead-dark">
            <tr>
              <th scope="col">item details</th>
              <th scope="col">quantity</th>
              <th scope="col">Rate</th>
              <th scope="col">discount</th>
              <th scope="col">amount</th>
            </tr>
          </thead>
          <tbody>
            {/* --------------first row--------------- */}
            <tr>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                  placeholder="type to select an item"
                />
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                  value="1.00"
                />
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                  value="0.00"
                />
              </td>
              <td>
                <div className="row">
                  <div className="col">
                    <input
                      type="text"
                      id="inputText"
                      className="form-control textInput"
                      style={{ width: "150px" }}
                      value="0.00"
                    />
                  </div>
                  <div className="col">
                    <Dropdown>
                      <Dropdown.Toggle
                        variant="Info"
                        id="dropdown-basic"
                      ></Dropdown.Toggle>

                      <Dropdown.Menu>
                        <Dropdown.Item href="#/action-1">%</Dropdown.Item>
                        <Dropdown.Item href="#/action-2">₹</Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </div>
                </div>
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                />
              </td>
              <td>
                <RxCross1 />
              </td>
            </tr>

            {/* --------------dynamic row--------------- */}

            {rows.map((row) => (
              <tr key={row.id}>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                    placeholder="type to select an item"
                  />
                </td>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                    value="1.00"
                  />
                </td>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                    value="0.00"
                  />
                </td>
                <td>
                  <div className="row">
                    <div className="col">
                      <input
                        type="text"
                        id="inputText"
                        className="form-control textInput"
                        style={{ width: "150px" }}
                        value="0.00"
                      />
                    </div>
                    <div className="col">
                      <Dropdown>
                        <Dropdown.Toggle
                          variant="Info"
                          id="dropdown-basic"
                        ></Dropdown.Toggle>

                        <Dropdown.Menu>
                          <Dropdown.Item href="#/action-1">%</Dropdown.Item>
                          <Dropdown.Item href="#/action-2">₹</Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                    </div>
                  </div>
                </td>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                  />
                </td>

                <td>
                  <RxCross1 />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ---------button----------    */}
      <div className="row">
        <div className="col-md-2 col-6">
          <Button variant="secondary" size="sm" onClick={addRow}>
            <AiFillPlusCircle
              data-bs-container="body"
              data-bs-toggle="popover"
              data-bs-placement="bottom"
              data-bs-content="Bottom popover"
            />
            &nbsp; add new row
          </Button>
        </div>
        <div className="col-md-2 col-6">
          <Button variant="secondary" size="sm">
            <AiFillPlusCircle
              data-bs-container="body"
              data-bs-toggle="popover"
              data-bs-placement="bottom"
              data-bs-content="Bottom popover"
            />
            &nbsp; add item in bulk
          </Button>
        </div>
        <div className="col-md-6 p-md-5 p-2 mt-2" style={{ background: "aliceblue" }}>
          <div className="row">
            <div className="col-md-4 col-4 text-start">
              <h6>subtotal</h6>
            </div>
            <div className="col-md-4 col-4 text-end"></div>
            <div className="col-md-4 col-4 ">0.00</div>
          </div>
          <div className="row mt-3">
            <div className="col-md-4 col-4">
              <input
                type="text"
                id="inputText"
                className="form-control  formInput"
              
              />
            </div>
            <div className="col-md-4 col-4">
              <input
                type="text"
                id="inputText"
                className="form-control  formInput"
                
              />
            </div>
            <div className="col-md-4 col-4">
              <p>0.00</p>
            </div>
          </div>

          <div className="row mt-2 border-top">
            <div className="col-md-6 col-6">
              <h4>Total (₹)</h4>
            </div>
            <div className="col-md-6 col-6">
              <h4>0.00</h4>
            </div>
          </div>
        </div>
        <div className="row g-3 ">
<div className="col-md-6 col-3 ">
                  <button
                    type="submit"
                    class="btn btn-primary float-end"
                
                  >
                    Save
                  </button>
                </div>
                <div className="col-md-6 col-3">
                  <button type="button" class="btn btn-outline-info float-start">
                    Cancel
                  </button>
                </div>
</div>
      </div>
      
    </div>
  )
}

export default DeliveryChallan