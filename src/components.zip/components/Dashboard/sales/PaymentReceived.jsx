import React, { useState, useRef } from "react";
import '../../../css/dashboard/items.css'
import Button from "react-bootstrap/Button";
import Overlay from "react-bootstrap/Overlay";
import { TiArrowSortedDown } from "react-icons/ti";
import { TiPlus } from "react-icons/ti";
import { IoSearch } from "react-icons/io5";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Dropdown from 'react-bootstrap/Dropdown';
import { AiFillPlusCircle } from "react-icons/ai";
import { RxCross1 } from "react-icons/rx";
import { IoDocumentTextOutline } from "react-icons/io5";
import Offcanvas from "react-bootstrap/Offcanvas";
import { MdDeleteForever } from "react-icons/md";


function PaymentReceived() {

    const [startDate, setStartDate] = useState(new Date());
    const [rows, setRows] = useState([]);
  
    const addRow = () => {
      const newRow = { id: rows.length + 1, data: 'New Row' };
      setRows([...rows, newRow]);
  };


  const [show, setShow] = useState(false);
  const [product, setProducts] = useState([]);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [show1, setShow1] = useState(false);
  const target1 = useRef(null);

  const [show2, setShow2] = useState(false);
  const target2 = useRef(null);

  const [type, setType] = useState("");
  const [name, setName] = useState("");
  const [unit, setUnit] = useState("");
  const [cost, setCost] = useState("");
  const [salesaccount, setSalesAccount] = useState("");
  const [desc, setDesc] = useState("");
  const [purchasecost, setPurchaseCost] = useState("");
  const [purchaseaccount, setPurchaseAccount] = useState("");
  const [purchasedisc, setPurchaseDisc] = useState("");

  const handleRadioChange = (event) => {
    setType(event.target.value);
  };

  const handleUnit = (event) => {
    setUnit(event.target.value);
  };

  const handleSalesAccount = (event) => {
    setSalesAccount(event.target.value);
  };

  const handlePurchaseAccount = (event) => {
    setPurchaseAccount(event.target.value);
  };

  const handleFormData = (e) => {
    e.preventDefault();
    const data = {
      id: `UNIT${Math.floor(Math.random() * 99999999999)}`,
      type,
      name,
      unit,
      cost,
      salesaccount,
      desc,
      purchasecost,
      purchaseaccount,
      purchasedisc,
    };
    setProducts([...product, data]);
    alert("item saved..");
  };

  const deleteProduct = (id) => {
    setProducts([...product.filter((item) => item.id !== id)]);
  };

  const sortByName=()=>{
    setProducts([...product.sort((a,b)=>a.name.localeCompare(b.name))]);
  }
  const sortByRate=()=>{
    setProducts([...product.sort((a,b)=>a.cost-b.cost)]);
  }

  const sortByPurchaseRate=()=>{
    setProducts([...product.sort((a,b)=>a.purchasecost-b.purchasecost)]);
  }

  return (
    <div>
      <div className="row border py-3 d-flex ">
        <div className="col-md-6">
          <Button
            variant="transparent"
            className="float-start"
            ref={target1}
            onClick={() => setShow1(!show1)}
          >
            All  <TiArrowSortedDown />
          </Button>
          <Overlay target={target1.current} show={show1} placement="bottom">
            {({
              placement: _placement,
              arrowProps: _arrowProps,
              show: _show,
              popper: _popper,
              hasDoneInitialMeasure: _hasDoneInitialMeasure,
              ...props
            }) => (
              <div
                {...props}
                style={{
                  position: "absolute",
                  backgroundColor: "",
                  padding: "2px 10px",
                  color: "black",
                  borderRadius: 3,
                  ...props.style,
                }}
              >
                <ul class="list-group">
                  <li class="list-group-item list-group-item-action">All</li>
                  <li class="list-group-item list-group-item-action">
                    Drft
                  </li>
                  <li class="list-group-item list-group-item-action">Pending Approval</li>
                  <li class="list-group-item list-group-item-action">
                   Locked
                  </li>
                  <li class="list-group-item list-group-item-action">
                  Approved
                  </li>
                  <li class="list-group-item list-group-item-action">
                  unpaid
                  </li>
                  <li class="list-group-item list-group-item-action">
                Overdue
                  </li>
                  <li class="list-group-item list-group-item-action">
               Paid
                  </li>
                </ul>
              </div>
            )}
          </Overlay>
        </div>

        <div className="col-md-6 d-flex justify-content-end">

          {/* < BsThreeDotsVertical className='menuDot'/> */}
        <div className="buttons">
        <button
            type="button"
            className="btn btn-primary d-inline"
            onClick={handleShow}
          >
            <TiPlus /> New
          </button>
        <Dropdown className="mx-3">
            <Dropdown.Toggle variant="transparent outline btn-outline-primary" id="dropdown-basic">
         Sort by
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item onClick={sortByName}>Date</Dropdown.Item>
              <Dropdown.Item onClick={sortByRate}>Invoice#</Dropdown.Item>
              <Dropdown.Item  onClick={sortByPurchaseRate}>Order Number</Dropdown.Item>
              <Dropdown.Item  onClick={sortByPurchaseRate}>Customer Namer</Dropdown.Item>
              <Dropdown.Item  onClick={sortByPurchaseRate}>Due Date</Dropdown.Item>
              <Dropdown.Item  onClick={sortByPurchaseRate}>Amount</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
        </div>
      </div>

      <div className="row">
        <div className="col-md-12 overflow-auto">
          <table class="table">
            <thead class="thead-light">
              <tr>
                <th scope="col">Date</th>
                <th scope="col">Invoice#</th>
                <th scope="col">Order Number</th>
                <th scope="col">Customer Name</th>
                <th scope="col">Status</th>
                <th scope="col">Due Date</th>
                <th scope="col">Amount</th>
                <th scope="col">Balance Due</th>
              </tr>
            </thead>
            {
              product.length!==0 ? (
                <tbody>
                {product.map((item) => {
                  return (
                    <tr key={item.id}>
                      <td>{item.name}</td>
                      <td>{item.desc}</td>
                      <td>{item.purchasedisc}</td>
                      <td>{item.cost}</td>
                      <td>{item.purchasecost}</td>
                      <td>{item.unit}</td>
                      <td>
                        <MdDeleteForever onClick={() => deleteProduct(item.id)} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              ):(
                <div className="container ">
     <div className="row mt-4   ">
      <div className="col-md-12 ">
      <img src="../images/emptybox.jpg" alt="" srcset="" style={{width:'200px',height:'200px',opacity:'0.4'}}/>
      <h6>There are no inactive items.</h6>
      </div>
     
          </div>
                </div>
           
              )
            }
          
          </table>
         
        </div>
      </div>

      {/* Off-Canvas--------------------------- */}

      <Offcanvas
        show={show}
        onHide={handleClose}
        placement="end"
        style={{ width: "1200px",backgroundColor:'white' }}
      >
        <Offcanvas.Header closeButton>
        </Offcanvas.Header>
        <Offcanvas.Body>
        <div className="row border-bottom py-2 text-start d-flex ">
        <h3>
        <IoDocumentTextOutline /> &nbsp;&nbsp; New Invoice
        </h3>
      </div>
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Customer Name*
          </label>
        </div>
        <div className="col-md-5 ">
          <div className="row">
            <div className="col-md-8 ">
            <div class="input-group mb-md-3 mb-0 textInput">
                      <input
                        type="text"
                        class="form-control"
                        placeholder="select customer"
                        aria-label="Recipient's username"
                        aria-describedby="button-addon2"
                      />
                      <button
                        class="btn btn-primary"
                        type="button"
                        id="button-addon2"
                      >
                        {" "}
                        <IoSearch style={{ fontSize: "22px" }} />
                      </button>
                    </div>
                      </div>
          </div>
        </div>
      </div>

      {/* ------sales ordder---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Invoice#*
          </label>
        </div>
        <div className="col-md-5">
          <input
            type="text"
            id="inputText"
            className="form-control textInput"
            required
            value="DC-00001"
          />
        </div>
      </div>

      {/* ------refrence---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Order Number
          </label>
        </div>
        <div className="col-md-5">
          <input
            type="text"
            id="inputText"
            className="form-control textInput"
          />
        </div>
      </div>

      {/* ------sales order date---------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
          Invoice Date*
          </label>
        </div>
        <div className="col-md-5  text-start">
          <DatePicker
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            className="textInput"
            style={{ outline: "none" }}
            required
          />
        </div>
      </div>

 {/* ------sales order date---------- */}
 <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Due Date
          </label>
        </div>
        <div className="col-md-5  text-start">
          <DatePicker
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            className="textInput"
            style={{ outline: "none" }}
            required
          />
        </div>
      </div>


      {/* -------------payment term--------------------- */}
      <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
           Terms
          </label>
        </div>
        <div className="col-md-5">
          <select
            className="form-select textInput"
            id="inputGroupSelect03"
            aria-label="Example select with button addon"
            placeholder='choose a proper challan type'
          >
            <option value="Net-15">Supply of Liquid gas</option>
            <option value="Net-30">Job work</option>
            <option value="Net-45">Other</option>
          </select>
        </div>
      </div>

   {/* -------------salesperson--------------------- */}
   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
        <div className="col-md-2 text-start">
          <label for="inputText" className="col-form-label label">
            Salesperson
          </label>
        </div>
        <div className="col-md-5">
          <select
            className="form-select textInput"
            id="inputGroupSelect03"
            aria-label="Example select with button addon"
            placeholder="select a delivery method"
          >
            <option value="Net-15">COD</option>
            <option value="Net-30">bffb</option>
            <option value="Net-45">dfn</option>
          </select>
        </div>
      </div>
   

{/* --------------item table------------- */}
      <div className="row mt-3 text-start">
        <h5 className="py-2 bg-secondary text-light">Item Table</h5>
      </div>

      <div className="row mt-1 overflow-auto">
        <table class="table table-striped">
          <thead className="thead-dark">
            <tr>
              <th scope="col">item details</th>
              <th scope="col">quantity</th>
              <th scope="col">Rate</th>
              <th scope="col">discount</th>
              <th scope="col">amount</th>
            </tr>
          </thead>
          <tbody>
            {/* --------------first row--------------- */}
            <tr>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                  placeholder="type to select an item"
                />
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                  value="1.00"
                />
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                  value="0.00"
                />
              </td>
              <td>
                <div className="row">
                  <div className="col">
                    <input
                      type="text"
                      id="inputText"
                      className="form-control textInput"
                      style={{ width: "150px" }}
                      value="0.00"
                    />
                  </div>
                  <div className="col">
                    <Dropdown>
                      <Dropdown.Toggle
                        variant="Info"
                        id="dropdown-basic"
                      ></Dropdown.Toggle>

                      <Dropdown.Menu>
                        <Dropdown.Item href="#/action-1">%</Dropdown.Item>
                        <Dropdown.Item href="#/action-2">₹</Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </div>
                </div>
              </td>
              <td>
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  style={{ width: "180px" }}
                />
              </td>
              <td>
                <RxCross1 />
              </td>
            </tr>

            {/* --------------dynamic row--------------- */}

            {rows.map((row) => (
              <tr key={row.id}>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                    placeholder="type to select an item"
                  />
                </td>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                    value="1.00"
                  />
                </td>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                    value="0.00"
                  />
                </td>
                <td>
                  <div className="row">
                    <div className="col">
                      <input
                        type="text"
                        id="inputText"
                        className="form-control textInput"
                        style={{ width: "150px" }}
                        value="0.00"
                      />
                    </div>
                    <div className="col">
                      <Dropdown>
                        <Dropdown.Toggle
                          variant="Info"
                          id="dropdown-basic"
                        ></Dropdown.Toggle>

                        <Dropdown.Menu>
                          <Dropdown.Item href="#/action-1">%</Dropdown.Item>
                          <Dropdown.Item href="#/action-2">₹</Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                    </div>
                  </div>
                </td>
                <td>
                  <input
                    type="text"
                    id="inputText"
                    className="form-control textInput"
                    style={{ width: "180px" }}
                  />
                </td>

                <td>
                  <RxCross1 />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ---------button----------    */}
      <div className="row">
        <div className="col-md-2 col-6">
          <Button variant="secondary" size="sm" onClick={addRow}>
            <AiFillPlusCircle
              data-bs-container="body"
              data-bs-toggle="popover"
              data-bs-placement="bottom"
              data-bs-content="Bottom popover"
            />
            &nbsp; add new row
          </Button>
        </div>
        <div className="col-md-2 col-6">
          <Button variant="secondary" size="sm">
            <AiFillPlusCircle
              data-bs-container="body"
              data-bs-toggle="popover"
              data-bs-placement="bottom"
              data-bs-content="Bottom popover"
            />
            &nbsp; add item in bulk
          </Button>
        </div>
        <div className="col-md-6 p-md-5 p-2 mt-1" style={{ background: "aliceblue",float:'right' }}>
          <div className="row">
            <div className="col-md-4 col-4 text-start">
              <h6>subtotal</h6>
            </div>
            <div className="col-md-4 col-4  "></div>
            <div className="col-md-4 col-4  text-end">0.00</div>
          </div>


          <div className="row mt-3">
    <div className="col-md-4 col-4 text-start">
   <small>Shipping Charges</small>
    </div>
    <div className="col-md-4 col-4">
    <input
              type="text"
              id="inputText"
              className="form-control  formInput"

            />
    </div>
    <div className="col-md-4 col-4 text-end">
    <p>0.00</p>
    </div>
  </div>



          <div className="row mt-3">
    <div className="col-md-4 col-4">
    <div className="row">
                  <div className="col-md-6">
                    <div class="form-check">
                      <input
                        class="form-check-input "
                        name="flexRadioDefault"
                        id="flexRadioDefault1"
                        type="radio"
                        value="TDS"
                    
                      />
                      <label class="form-check-label" for="flexRadioDefault1">
                        TDS
                      </label>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div class="form-check">
                      <input
                        class="form-check-input "
                        type="radio"
                        name="flexRadioDefault"
                        id="flexRadioDefault1"
                        value="TCS"
                
                      />
                      <label class="form-check-label" for="flexRadioDefault1">
                       TCS
                      </label>
                    </div>
                  </div>
                </div>
    </div>
    <div className="col-md-4 col-4">
    <select
                  className="form-select formInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon "
               
                >
                  <option value="INR">select a tax</option>
                  <option value="USD"></option>
                  <option value="JPY"></option>
                </select>
    </div>
    <div className="col-md-4 col-4 text-end">
    <p>0.00</p>
    </div>
  </div>


          <div className="row mt-3">
            <div className="col-md-4 col-4">
              <input
                type="text"
                id="inputText"
                className="form-control  formInput"
            
              />
            </div>
            <div className="col-md-4 col-4">
              <input
                type="text"
                id="inputText"
                className="form-control  formInput"
               
              />
            </div>
            <div className="col-md-4 col-4 text-end">
              <p>0.00</p>
            </div>
          </div>


          <div className="row mt-2 border-top">
            <div className="col-md-6 col-6">
              <h4>Total (₹)</h4>
            </div>
            <div className="col-md-6 col-6 text-end">
              <h4>0.00</h4>
            </div>
          </div>
        </div>
      </div>
        </Offcanvas.Body>
      </Offcanvas>

      {/* off-canvas End ------------------ */}
    </div>
  );
}

export default PaymentReceived;
