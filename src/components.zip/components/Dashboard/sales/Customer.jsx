import React, { useState } from "react";
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import '../../../css/dashboard/customer.css'

function Customer() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [type,setType]=useState('')
  const [firstname,setFirstName]=useState('')
  const [lastname,setLastName]=useState('')

  




  const [formData, setFormData] = useState({
    customertype:type,
    firstname: firstname,
    lastname: lastname,
    companyname:'',
    displayname:'',
    email: '',
    phone: '',
    pan:'',
    currency:'',
    openingbalance:'',
    paymentterm:'',
    portalLanguage:'',
    document:selectedFile,
    billingAddress:{
      attension:'',
      country:'',
      address:'',
      city:'',
      state:'',
      pincode:'',
      phone:'',
      faxnumber:''
    },
    shippingAddress:{
      attension:'',
      country:'',
      address:'',
      city:'',
      state:'',
      pincode:'',
      phone:'',
      faxnumber:''
    },
    contactPerson:{
      firstname:'',
      lastname:'',
      emailaddress:'',
      workphone:'',
      designation:'',
      department:''
    }

  });

  

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData); // Example: log form data to console
  
   
  };


  const handleRadioChange = (event) => {
    setType(event.target.value);
  };




  return (
    <div>
      <div className="row border-bottom py-2 text-start d-flex ">
        <h3>New Customer</h3>
      </div>

      {/* --customer type---- */}
      <form class="row g-md-3 g-1 needs-validation" novalidate onSubmit={handleSubmit}>
        <div className="row g-3 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Type
            </label>
          </div>
          <div className="col-md-3">
            <div className="row">
              <div className="col-md-5 col-3">
                <div class="form-check">
                  <input
                    class="form-check-input"
                    name="flexRadioDefault"
                    id="flexRadioDefault1"
                    type="radio"
                    value="business"
                    checked={type === "business"}
                    onChange={handleRadioChange}
                  />
                  <label class="form-check-label" for="flexRadioDefault1">
                    Business
                  </label>
                </div>
              </div>
              <div className="col-md-5 col-3">
                <div class="form-check">
                  <input
                    class="form-check-input"
                    type="radio"
                    name="flexRadioDefault"
                    id="flexRadioDefault1"
                    value="individual"
                    checked={type === "individual"}
                    onChange={handleRadioChange}
                  />
                  <label class="form-check-label" for="flexRadioDefault1">
                    Individual
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* --customer name---- */}
        <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Primary Contact*
            </label>
          </div>
          <div className="col-md-10">
            <div className="row gy-1">
              <div className="col-md-5">
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  required
                  value={formData.firstname} 
                  onChange={(e)=>setFormData(formData.firstname=e.target.value)}
                  placeholder="First Name"
                />
              </div>
              <div className="col-md-5">
                <input
                  type="text"
                  id="inputText"
                  className="form-control textInput"
                  required
                  value={formData.lastname} 
            onChange={(e)=>setFormData(formData.lastname=e.target.value)}
                  placeholder="Last Name"
                />
              </div>
            </div>
          </div>
        </div>

        {/* ------company name---------- */}
        <div className="row  mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Company Name
            </label>
          </div>
          <div className="col-md-5">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value={formData.companyname} 
               
            />
          </div>
        </div>

        {/* ------customer display name---------- */}
        <div className="row  mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Customer Display Name
            </label>
          </div>
          <div className="col-md-5">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value={formData.displayname} 
               
            />
          </div>
        </div>

        {/* ------customer email ---------- */}
        <div className="row  mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Customer Email
            </label>
          </div>
          <div className="col-md-5">
            <div class="input-group flex-nowrap textInput">
              <span class="input-group-text" id="addon-wrapping">
                <img src="../images/email-icon.png" alt="" srcset="" />
              </span>
              <input
                type="email"
                class="form-control "
                required
                value={formData.email} 
                 
                aria-label="Username"
                aria-describedby="addon-wrapping"
              />
            </div>
          </div>
        </div>

        {/* ------customer phone number---------- */}
        <div className="row  mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
              Customer Phone
            </label>
          </div>
          <div className="col-md-5">
            <div class="input-group flex-nowrap textInput">
              <span class="input-group-text" id="addon-wrapping">
                <img src="../images/phone-icon.png" alt="" srcset="" />
              </span>
              <input
                type="number"
                class="form-control "
                required
                value={formData.phone} 
                 
                aria-label="Username"
                aria-describedby="addon-wrapping"
              />
            </div>
          </div>
        </div>


{/* ----------------Tabs starting---------- */}
<div className="row my-5">
<Tabs
      defaultActiveKey="other"
      id="uncontrolled-tab-example"
      className="mb-3"
    >
        {/* -------------other details tab starting---------- */}
      <Tab eventKey="other" title="Other details" >
     {/* ---------------------------------- */}
     <div className="row  g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
            PAN
            </label>
          </div>
          <div className="col-md-5">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value={formData.pan} 
               
            />
          </div>
        </div>

   {/* ---------------------------------- */}
        <div className="row  mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-2 text-start">
                <label for="inputText" className="col-form-label label">
                 Currency
                </label>
              </div>
              <div className="col-md-5">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                  value={formData.currency} 
                   
                >
                  <option value="INR">INR - Indian Rupee</option>
                  <option value="USD">USD - US Dollar</option>
                  <option value="JPY">JPY - japani yen</option>
                </select>
              </div>
            </div>

   {/* ---------------------------------- */}
            <div className="row  mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-2 text-start">
            <label for="inputText" className="col-form-label label">
            Opening Balance
            </label>
          </div>
          <div className="col-md-5">
            <div class="input-group flex-nowrap textInput">
              <span class="input-group-text" id="addon-wrapping">
               INR
              </span>
              <input
                type="email"
                class="form-control "
                required
                aria-label="Username"
                aria-describedby="addon-wrapping"
                value={formData.openingbalance} 
                 
              />
            </div>
          </div>
        </div>

 {/* ---------------------------------- */}
 <div className="row  mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-2 text-start">
                <label for="inputText" className="col-form-label label">
                Payment Term
                </label>
              </div>
              <div className="col-md-5">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                  value={formData.paymentterm} 
                   
                >
                    <option value="Net-15">Net 15</option>
                    <option value="Net-30">Net 30</option>
                    <option value="Net-45">Net 45</option>
                    <option value="Net-60">Net 60</option>
                    <option value="Due end of the month" active>Due end of the month</option>
                    <option value="Due end of the next month" active>Due end of the next month</option>
                  <option value="Due on Receipt" active>Due on Receipt</option>
                  
                </select>
              </div>
            </div>

     {/* ---------------------------------- */}
 <div className="row  mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-2 text-start">
                <label for="inputText" className="col-form-label label">
                Portal Language
                </label>
              </div>
              <div className="col-md-5">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                  value={formData.portalLanguage} 
                   
                >
                    <option value="English">English</option>
                    <option value="Kannada">Kannada</option>
                    <option value="Hindi">Hindi</option>
                    <option value="Gujrati">Gujrati</option>
                    <option value="Marathi" >Marathi</option>
                 
                  
                </select>
              </div>
            </div>


     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-2 text-start">
                <label for="inputText" className="col-form-label label">
                Documents
                </label>
              </div>
              <div className="col-md-5">
            
              <div class="input-group mb-3 textInput">
  <input type="file" class="form-control" id="inputGroupFile02" onChange={(e)=>setSelectedFile(e.target.files[0])}/>
</div>
              </div>
            </div>

      </Tab>
      {/* -------------Address tab starting---------- */}
      <Tab eventKey="address" title="Address">
        <div className="row">
            <div className="col-md-6 ">
                <div className="row text-start mb-md-3 mb-0">
                    <h6>Billing Address</h6>
                </div>

                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
              Attension
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value={formData.billingAddress.attension} 
               
            />
          </div>
        </div>

     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-4 text-start">
                <label for="inputText" className="col-form-label label">
                Country/Region
                </label>
              </div>
              <div className="col-md-7">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                  value={formData.billingAddress.country} 
               
                >
                    <option value="English">India</option>
                    <option value="Kannada">Afganistan</option>
                    <option value="Hindi">Sri Lanka</option>
                    <option value="Gujrati">Nepal</option>
                    <option value="Marathi" >China</option>
                    <option value="Marathi" >Bhutan</option>
                  
                </select>
              </div>
            </div>

{/* ---------------------------------- */}
            <div className="row mt-3">
                  <div className="col-md-4 text-start">
                    <label for="inputText" className="col-form-label label">
                     Address
                    </label>
                  </div>
                  <div className="col-md-7">
                    <div className="form-floating">
                      <textarea
                        className="form-control"
                        placeholder="Street 1"
                        id="floatingTextarea2"
                        style={{ height: "70px" }}
                        value={formData.billingAddress.address} 
               
                      ></textarea>
                    </div>
                  </div>
                </div>



                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             City
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value={formData.billingAddress.city} 
               
            />
          </div>
        </div>



     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-4 text-start">
                <label for="inputText" className="col-form-label label">
              State
                </label>
              </div>
              <div className="col-md-7">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                  value={formData.billingAddress.state} 
               
                >
                    <option value="English">Arunachal Pradesh</option>
                    <option value="Kannada">Telangana</option>
                    <option value="Hindi">Gujrat</option>
                    <option value="Gujrati">Maharashtra</option>
                    <option value="Marathi" >Karnataka</option>
                    <option value="Marathi" >Madhyapradesh</option>
                    <option value="Marathi" >Chhattisgrah</option>
                  
                </select>
              </div>
            </div>



                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             PinCode
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value={formData.billingAddress.pincode} 
               
            />
          </div>
        </div>


                  {/* ---------------------------------- */}
                  <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             Phone
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value={formData.billingAddress.phone} 
               
            />
          </div>
        </div>


                  {/* ---------------------------------- */}
                  <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             Fax Number
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              value={formData.billingAddress.faxnumber} 
               
            />
          </div>
        </div>

            </div>
            <div className="col-md-6 ">
                <div className="row text-start mb-md-3 mb-0 mt-md-0 mt-3">
                    <h6>Shipping Address</h6>
                </div>

                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
              Attension
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              value={formData.shippingAddress.attension} 
               

            />
          </div>
        </div>

     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-4 text-start">
                <label for="inputText" className="col-form-label label">
                Country/Region
                </label>
              </div>
              <div className="col-md-7">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                  value={formData.shippingAddress.country} 
                   
                >
                    <option value="English">India</option>
                    <option value="Kannada">Afganistan</option>
                    <option value="Hindi">Sri Lanka</option>
                    <option value="Gujrati">Nepal</option>
                    <option value="Marathi" >China</option>
                    <option value="Marathi" >Bhutan</option>
                  
                </select>
              </div>
            </div>

{/* ---------------------------------- */}
            <div className="row mt-3">
                  <div className="col-md-4 text-start">
                    <label for="inputText" className="col-form-label label">
                     Address
                    </label>
                  </div>
                  <div className="col-md-7">
                    <div className="form-floating">
                      <textarea
                        className="form-control"
                        placeholder="Street 1"
                        id="floatingTextarea2"
                        style={{ height: "70px" }}
                        value={formData.shippingAddress.address} 
                         
                      ></textarea>
                    </div>
                  </div>
                </div>



                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             City
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value={formData.shippingAddress.city} 
               

            />
          </div>
        </div>



     {/* ---------------------------------- */}
     <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
              <div className="col-md-4 text-start">
                <label for="inputText" className="col-form-label label">
              State
                </label>
              </div>
              <div className="col-md-7">
                <select
                  className="form-select textInput"
                 
                  id="inputGroupSelect03"
                  aria-label="Example select with button addon"
                  required
                  value={formData.shippingAddress.state} 
                   
                >
                    <option value="English">Arunachal Pradesh</option>
                    <option value="Kannada">Telangana</option>
                    <option value="Hindi">Gujrat</option>
                    <option value="Gujrati">Maharashtra</option>
                    <option value="Marathi" >Karnataka</option>
                    <option value="Marathi" >Madhyapradesh</option>
                    <option value="Marathi" >Chhattisgrah</option>
                  
                </select>
              </div>
            </div>



                   {/* ---------------------------------- */}
                   <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             PinCode
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
           
              value={formData.shippingAddress.pincode} 
               

            />
          </div>
        </div>


                  {/* ---------------------------------- */}
                  <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             Phone
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              required
              value={formData.shippingAddress.phone} 
               
            />
          </div>
        </div>


                  {/* ---------------------------------- */}
                  <div className="row mt-md-2 mt-1 g-md-3 g-1 align-items-center">
          <div className="col-md-4 text-start">
            <label for="inputText" className="col-form-label label">
             Fax Number
            </label>
          </div>
          <div className="col-md-7">
            <input
              type="text"
              id="inputText"
              className="form-control textInput"
              value={formData.shippingAddress.faxnumber} 
               

            />
          </div>
        </div>

            </div>
        </div>

      </Tab>

{/* ------------contact person tab starting---------- */}

      <Tab eventKey="contactperson" title="Contact Person" >
      <div className="row overflow-auto">
        <div className="col-md-12">
<table class="table">
  <thead>
    <tr>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email Address</th>
      <th scope="col">Work Phone</th>
      <th scope="col">Designation</th>
      <th scope="col">Department</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
        style={{width:'180px'}}
        value={formData.contactPerson.firstname} 
         
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"

        style={{width:'180px'}}
        value={formData.contactPerson.lastname} 
         
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
        style={{width:'180px'}}
        value={formData.contactPerson.emailaddress} 
         
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
        style={{width:'180px'}}
        value={formData.contactPerson.workphone} 
         
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
              value={formData.contactPerson.designation} 
         
        style={{width:'180px'}}
            />
      </td>
      <td>
      <input
              type="text"
              id="inputText"
              className="form-control"
              value={formData.contactPerson.department} 
         
        style={{width:'180px'}}
            />
      </td>
    </tr>
    
  </tbody>
</table>
        </div>
      </div>
      </Tab>
      <Tab eventKey="remarks" title="Remarks" >
     <div className="row">
        Remarks (for internal use)
        <br />
        <div className="col-md-7">
        
                    <div className="form-floating">
                      <textarea
                        className="form-control"
                        placeholder="Street 1"
                        id="floatingTextarea2"
                        style={{ height: "70px" }}
                      ></textarea>
                    </div>
                  </div>
     </div>
      </Tab>

    </Tabs>
    <div className="row g-3 ">
<div className="col-md-6 col-3 ">
                  <button
                    type="submit"
                    class="btn btn-primary float-end"
                
                  >
                    Save
                  </button>
                </div>
                <div className="col-md-6 col-3">
                  <button type="button" class="btn btn-outline-info float-start">
                    Cancel
                  </button>
                </div>
</div>
</div>


      </form>



    </div>
  );
}

export default Customer;
