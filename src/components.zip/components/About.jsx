import React,{useEffect} from "react";
import "../css/about.css";
import NavBar from "./Navbar";
import { TbTargetArrow } from "react-icons/tb";
import OwlCarousel from "react-owl-carousel";
import AOS from "aos";
import "aos/dist/aos.css";
import MovingText from 'react-moving-text'
import {Link} from 'react-router-dom'

function About() {
  const options = {
    margin: 30,
    responsiveClass: true,
    nav: false,
    dots: true,
    autoplay: true,
    smartSpeed: 1000,
    responsive: {
      0: {
        items: 1,
      },
      400: {
        items: 1,
      },
      600: {
        items: 1,
      },
      700: {
        items: 1,
      },
      1000: {
        items: 1,
      },
    },
  };

  useEffect(() => {
    AOS.init({ duration: "900" });
  }, [])


  return (
    <div>
      <div className="aboutbanner">
        <NavBar />
        <div className="innerDiv ">
          <h1 className="text-start ">About Us</h1>
          <div className="breadcrumbdiv">
          <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item "><Link to='/'>Home</Link></li>
    <li class="breadcrumb-item " ><Link to="/aboutus">About Us</Link></li>
  </ol>
</nav>
          </div>
        </div>
      </div>

      <div className="container-fluid" style={{ backgroundColor: "#f5f5f5" }} data-aos='slide-up'>
        <div className="row d-flex  justify-content-center customeRow1">
          <div className="col-md-4 my-5 d-flex   flex-column">
            <img
              src="../images/about1.png"
              alt=""
              srcset=""
              className="abou1"
            />
          </div>
          <div className="col-md-7 my-5  custCol">
            <h3 className="aboutHead">ABOUT US</h3>
            <p className="aboutP">
              Welcome to [Company Name], your trusted partner in delivering
              high-quality ready-mix concrete solutions tailored to meet your
              construction needs. With a steadfast commitment to excellence and
              reliability, we have been serving [location or region] for
              [number] years, establishing ourselves as a cornerstone in the
              construction industry.
            </p>
            <br />
            <div style={{ textAlign: "left", paddingLeft: "20px" }}>
              <h5 style={{ display: "inline" }} className="aboutHead2">Our Mission</h5>
              <img
                src="../images/target.png"
                alt=""
                srcset=""
                className="target"
              />
              <img
                src="../images/arrow.png"
                alt=""
                srcset=""
                className="arrow"
              />
            </div>

            <p className="aboutP">
              At [Company Name], our mission is clear: to provide superior
              ready-mix concrete products and unmatched customer service that
              exceed industry standards. We strive to contribute positively to
              the success of every project we undertake, ensuring durable and
              sustainable concrete solutions.
            </p>
          </div>
        </div>
      </div>
{/* 
      <div className="chooseUsPart1" data-aos='slide-up'>
        <div className="innerContainer">
          <div className="heading mt-5">
            <div className="hline"></div>
            <h2>Why Choose Us</h2>
            <div className="hline"></div>
          </div>

          <div className="reason mb-5">
            <div className="innerCard1">
              <div className="imgSection">
                <img src="../images/mixer1.jpg" alt="" srcset="" />
              </div>
              <div className="textSection">
                <h6>Producing Cement of the Highest Quality</h6>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla
                  neque quam, maxi ut accumsan ut, posuere sit Lorem ipsum quam,
                  maximus ut accumsan.
                </p>
              </div>
            </div>
            <div className="innerCard1">
              <div className="imgSection">
                <img src="../images/mixer1.jpg" alt="" srcset="" />
              </div>
              <div className="textSection">
                <h6>Reliable Partner for Your Construction</h6>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla
                  neque quam, maxi ut accumsan ut, posuere sit Lorem ipsum quam,
                  maximus ut accumsan.
                </p>
              </div>
            </div>
            <div className="innerCard1">
              <div className="imgSection">
                <img src="../images/mixer1.jpg" alt="" srcset="" />
              </div>
              <div className="textSection">
                <h6>The Leading Manufacturer and Concrete Company</h6>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla
                  neque quam, maxi ut accumsan ut, posuere sit Lorem ipsum quam,
                  maximus ut accumsan.
                </p>
              </div>
            </div>
            <div className="innerCard1">
              <div className="imgSection">
                <img src="../images/mixer1.jpg" alt="" srcset="" />
              </div>
              <div className="textSection">
                <h6>Producing Cement of the Highest Quality</h6>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla
                  neque quam, maxi ut accumsan ut, posuere sit Lorem ipsum quam,
                  maximus ut accumsan.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div> */}
         <div className="chooseUsPart" data-aos='slide-up'>
        <div className="innerContainer mt-3">
           <div className="heading">
            <div className="hline"></div>
            <h2>Why Choose Us</h2>
            <div className="hline"></div>
           </div>
        
      <div className="reasons">
        <div className="innerCard">
        <img src="../images/durable.png" alt="" srcset="" />
        <p >Durable Concrete</p>
        </div>
        <div className="innerCard">
        <img src="../images/environment.png" alt="" srcset="" />
        <p>Environment Friendly</p>
        </div>
        <div className="innerCard">
        <img src="../images/delivery.png" alt="" srcset="" />
        <p>Timely Delivery</p>
        </div>
        <div className="innerCard">
        <img src="../images/cost.png" alt="" srcset="" />
        <p>Cost Effective</p>
        </div>
      </div>
     
        </div>
      </div>

      <div className="container-fluid  d-flex flex-column align-items-center" style={{ background: "#f5f5f5" }}>
        <div className="row d-flex justify-content-center align-items-center" style={{width:'100%'}}>
            <h2 style={{marginTop:'40px'}} className="aboutHead2 text-center">What Clients Say</h2>
        </div>
        <div className="row gx-5 d-flex justify-content-center align-items-center" style={{width:'100%'}}>
          <div className="col-md-5 my-5  imgCol">
            <div class="card card1 border-0" >
              <img src="../images/concrete-mixer.jpg" alt="" srcset="" />
            </div>
            <div class="card card2 border-0" >
              <img src="../images/mixer1.jpg" alt="" srcset="" />
            </div>
          </div>
          <div className="col-md-5 d-flex  align-items-center">
            <OwlCarousel loop margin={5} nav {...options} >
              <div class="item ">
                <div class="card testimonial">
                  <div className="photoSection">
                    <img
                      src="../images/testimonial1.jpg"
                      alt=""
                      srcset=""
                      className="testimonialImg"
                    />
                  </div>
                  <div className="review">
                    <p>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit.
                      Obcaecati, quasi possimus. Autem nulla fuga ad minus
                      inventore tempore, sapiente officia. Praesentium pariatur
                      hic, aperiam aut magni natus omnis voluptas corrupti!
                    </p>
                  </div>
                  <div className="name">
                    <h5>Ahoy Das</h5>
                    <h6>Head of XYZ company</h6>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="card testimonial">
                  <div className="photoSection">
                    <img src="../images/testimonial2.jpg" alt="" srcset="" />
                  </div>
                  <div className="review">
                    <p>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit.
                      Obcaecati, quasi possimus. Autem nulla fuga ad minus
                      inventore tempore, sapiente officia. Praesentium pariatur
                      hic, aperiam aut magni natus omnis voluptas corrupti!
                    </p>
                  </div>
                  <div className="name">
                    <h5>Ahoy Das</h5>
                    <h6>Head of XYZ company</h6>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="card testimonial">
                  <div className="photoSection">
                    <img src="../images/testimonial3.jpg" alt="" srcset="" />
                  </div>
                  <div className="review">
                    <p>
                      Lorem ipsum dolor sit amet consectetur adipisicing elit.
                      Obcaecati, quasi possimus. Autem nulla fuga ad minus
                      inventore tempore, sapiente officia. Praesentium pariatur
                      hic, aperiam aut magni natus omnis voluptas corrupti!
                    </p>
                  </div>
                  <div className="name">
                    <h5>Ahoy Das</h5>
                    <h6>Head of XYZ company</h6>
                  </div>
                </div>
              </div>
            </OwlCarousel>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
