import React, { useRef,useEffect } from "react";
import NavBar from "./Navbar";
import "../css/service.css";
import { FaCircleArrowRight } from "react-icons/fa6";
import { MdOutlinePhone } from "react-icons/md";
import { MdOutlineMail } from "react-icons/md";
import AOS from "aos";
import "aos/dist/aos.css";
import {Link} from 'react-router-dom'

function Service() {
  const myRef = useRef(null);
  const myRef2 = useRef(null);
  const myRef3 = useRef(null);

  const myRef4 = useRef(null);
  const myRef5 = useRef(null);
  const myRef6 = useRef(null);

  const myRef7 = useRef(null);
  const myRef8 = useRef(null);
  const myRef9 = useRef(null);

  const myRef10 = useRef(null);
  const myRef11 = useRef(null);
  const myRef12 = useRef(null);
  const spreadCard1 = () => [
    (myRef.current.style.width = "100%"),
    (myRef2.current.style.display = "none"),
    (myRef3.current.style.height='170px'),
    (myRef3.current.style.width='70%')
  ];

  const spreadCard2 = () => [
    (myRef4.current.style.width = "100%"),
    (myRef5.current.style.display = "none"),
    (myRef6.current.style.height='170px'),
    (myRef6.current.style.width='70%')
  ];

  const spreadCard3 = () => [
    (myRef7.current.style.width = "100%"),
    (myRef8.current.style.display = "none"),
    (myRef9.current.style.height='170px'),
    (myRef9.current.style.width='70%')
  ];

  const spreadCard4 = () => [
    (myRef10.current.style.width = "100%"),
    (myRef11.current.style.display = "none"),
    (myRef12.current.style.height='170px'),
    (myRef12.current.style.width='70%')
  ];
  useEffect(() => {
    AOS.init({ duration: "900" });
  }, [])
  return (
    <div>
      <div className="aboutbanner">
        <NavBar />
        <div className="innerDiv">
          <h1>Services</h1>
          <div className="breadcrumbdiv">
          <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item "><Link to="/">Home</Link></li>
    <li class="breadcrumb-item " ><Link to="/service">Service</Link></li>
  </ol>
</nav>
          </div>
        </div>
      </div>

      <div className="container  myContainer" >
      <div className="slider mt-5" ref={myRef10} data-aos='slide-up'>
          <div className="sliderImg">
            <img src="../images/prod1.jpg" alt="" srcset="" />
          </div>
          <div className="textPart" ref={myRef12}>
            <h5>Standard Ready-Mix Concrete</h5>
            <p>
            Standard ready-mix concrete is the most common form of concrete. It is prepared for delivery at a concrete plant instead of mixed on the construction site, which guarantees the quality of the concrete.
            </p>
          </div>
          <div className="arrowPart" onClick={spreadCard4} ref={myRef11}>
            <FaCircleArrowRight className="arrowcircle" />
          </div>
        </div>

        <div className="slider mt-5" ref={myRef} data-aos='slide-up'>
          <div className="sliderImg">
            <img src="../images/prod2.jpg" alt="" srcset="" />
          </div>
          <div className="textPart" ref={myRef3}>
            <h5>Fiber-reinforced Concrete</h5>
            <p>
              Concrete designed with steel or synthetic fibers. Steel fiber
              reinforced concrete can be used for ground supported slabs where
              the use of conventional reinforcement can be eliminated improving
              the ductility, toughness, fatigue and abrasion resistance while
              the use of synthetic fibers can reduce the plastic shrinkage
              cracks in concrete and eliminate spalling of concrete in case of
              fire situations.
            </p>
          </div>
          <div className="arrowPart" onClick={spreadCard1} ref={myRef2}>
            <FaCircleArrowRight className="arrowcircle" />
          </div>
        </div>

        <div className="slider mt-5" ref={myRef4} data-aos='slide-up'>
          <div className="sliderImg">
            <img src="../images/prod3.jpg" alt="" srcset="" />
          </div>
          <div className="textPart" ref={myRef6}>
            <h5>Self-Consolidating Concrete</h5>
            <p>
            SCC is type of concrete which has high flow and is designed as per the guidelines given by EFNARC, which eliminates the need for vibration of concrete and reach the areas in the formwork where normal concrete cannot reach with vibration in cases of heavily congested reinforcement, thinner sections and speciality architectural structures.
            </p>
          </div>
          <div className="arrowPart" onClick={spreadCard2} ref={myRef5}>
            <FaCircleArrowRight className="arrowcircle" />
          </div>
        </div>

        <div className="slider mt-5" ref={myRef7} data-aos='slide-up'>
          <div className="sliderImg">
            <img src="../images/prod5.jpg" alt="" srcset="" />
          </div>
          <div className="textPart" ref={myRef9}>
            <h5>Pervious Concrete</h5>
            <p>
            Because of its unique design mix, pervious concrete is a highly porous material that permits rain and storm water runoffs to percolate through it and regenerate the water table. It is ideally used in parking lots, footpaths, and swimming pool border applications
            </p>
          </div>
          <div className="arrowPart" onClick={spreadCard3} ref={myRef8}>
            <FaCircleArrowRight className="arrowcircle" />
          </div>
        </div>

      </div>

      <div className="contactInfo" data-aos='slide-up'>
        <div className="content">
        <h2>Get Started Today</h2>
        <p>
        Whether you have a specific project in mind or need guidance on the best concrete solutions for your needs, [Company Name] is here to help. Contact us today to schedule a consultation or request a quote. Let us bring your concrete visions to life with precision and professionalism.
        </p>
  
        <div className="div">
        <MdOutlinePhone className="callIcon"/>&nbsp;&nbsp;&nbsp;&nbsp; +91-72332323
  
        </div>
        <div className="div">
        <MdOutlineMail className="callIcon"/>&nbsp;&nbsp; xyzinfo@gmail.com
        </div>
        </div>

      </div>
    </div>
  );
}

export default Service;
