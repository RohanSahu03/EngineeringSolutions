import React, { useRef, useState } from 'react'
import '../css/login.css'
import NavBar from './Navbar'
import { MdEmail } from 'react-icons/md'
import { useNavigate } from 'react-router-dom'


function Login() {
    const [show, setShow] = useState(false);
    const [email,setEmail]=useState('')
    const [password,setPassword]=useState('')
    const myRef=useRef('none')
    const myRef2=useRef(null)
    const myRef3=useRef('none')
    const myRef4=useRef('none')
    const navigate=useNavigate()

const handleEmail=()=>{
if(email!==''){
    myRef.current.style.display='block'
    myRef2.current.style.display='none'
    myRef3.current.style.display='block'
}
else{
  myRef4.current.style.display='block'
}
}

const SignIn=()=>{
  alert('successfully logged in..')
    navigate('/dashboard')

}

  return (
    <div>
        <NavBar/>
        <div className="container-fluid  myContainer2">
            <div className="row  d-flex justify-content-center" style={{isolation:'isolate'}}>
                <div className="col-md-5 border rounded-4 mt-4 p-5 myCol1">
                <div className="row ">
            <img src="../images/logo2.jpeg" alt="" srcset="" className='logoImg'/>
        </div>
        <div className="row text-start">
         <span style={{fontWeight:'400',fontSize:'25px',paddingLeft:'0px',  fontFamily: "Playwrite DE Grund",fontStyle:'cursive'}}>Sign in</span>
           to access xyz
        </div>

<div className="row text-staer" ref={myRef} style={{display:'none'}}>
<input type="email" name="" id="" className='myInput2' value={email} disabled/>
</div>

<div className="row" ref={myRef2}>
<form >
  <div class="row text-start">
  <input type="email" name="" id="" className='myInput1' placeholder='Email Address or Mobile number' required value={email} onChange={(e)=>setEmail(e.target.value)}/>
    <br />
    <small style={{color:'red',display:'none'}} ref={myRef4}>Enter valid email</small>
  </div>
  <div class="row text-start">


<button type='button' className='button1' onClick={handleEmail} >Next</button>

  </div>
</form>

</div>

<div className="row" ref={myRef3} style={{display:'none'}}>
<form onSubmit={handleEmail}>
  <div class="row text-start">
  <input type="password" name="" id="" className='myInput1' placeholder='Enter Password' required value={password} onChange={(e)=>setPassword(e.target.value)}/>

  </div>
  <div class="row text-start">
    <a href="#"> Forgot Password ?</a>

  </div>
  <div class="row text-start">

<button type='button' className='button1' onClick={SignIn}>Sign in</button>

  </div>
</form>

</div>



<div className="row text-start mt-5">
    <h6>Sign in using</h6>
    <br />
   <div className="col-md-2">
   <a href="">
        <img src="../images/google.png" alt="" srcset="" className='googleImg'/>
    </a>

   </div>
   <div className="col-md-2">
   <a href="">
        <img src="../images/facebook.png" alt="" srcset="" className='facebookImg'/>
    </a>
   </div>
</div>
                </div>
            </div>
        </div>

    </div>
  )
}

export default Login