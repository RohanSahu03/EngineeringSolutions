import React from 'react'
import '../css/footer.css'
import { AiTwotoneMail } from "react-icons/ai";
import { MdOutlineCall } from "react-icons/md";
import { PiBuildingOfficeBold } from "react-icons/pi";
import { FaFacebookF } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FaSquareInstagram } from "react-icons/fa6";

function Footer() {
  return (
    <div>
        <footer className="footer p-5">
            {/* <div className="container-fluid">
             <div className="top">
                <div  className='border-end-md d-flex justify-content-center align-items-center'>
                <img src="../images/logo2.jpeg" alt="" srcset="" className='logoImg'/>
                </div>
                <div className='border-end-md'>
                <div>
                        <AiTwotoneMail size={30} color={'white'} />
                    </div>
                    <div>
                        needhelp@gmail.com
                    </div>
                </div>
                <div  className='border-end-md'>
                <div>
                        <MdOutlineCall size={30} color={'white'} />
                    </div>
                    <div>
                    +91-98765341
                    </div>
                </div>
                <div>
                <div>
                        <PiBuildingOfficeBold size={30} color={'white'} />
                    </div>
                    <div>
                    80 Brooklyn Golden Street, New York,USA
                    </div>
                </div>
             </div>
            </div> */}
            <div className="container">
                <div className="main">
                    <div className="about">
                        <h5>About</h5>
                        <p>
                        There are many variations of passages of lorem ipsum available, but the majority suffered.
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore, quas voluptatem veritatis, quae illo earum sapiente perferendis sint.
                        </p>
                    </div>
                    <div className="links">
                        <h5>Links</h5>
                        <ul>
                        <li>
                            <a href="/">Home</a>
                        </li>
                            <li>
                              <a href="/aboutus">About</a>
                            </li>
                            <li>
                                <a href="/service">
                                Our Services</a>
                            </li>
                           
                            <li>
                               <a href="/contactus"> Contact Us</a>
                            </li>
                        
                        </ul>
                    </div>
                    <div className="links ">
                        <h5>Contact Us</h5>
                        <ul>
                        <li>
                        <div className='d-flex'>
                        <img src="../images/call2.png" alt="" srcset="" />&nbsp;+910000000002
                        </div>
                        </li>
                            <li>
                            <div className='d-flex'>
                        <img src="../images/email2.png" alt="" srcset="" />&nbsp;needhelp@gmail.com
                        </div>
                            </li>
                            <li>
                            <div className='d-flex'>
                                <div>
                                <img src="../images/address.png" alt="" srcset="" />
                                </div>
                            &nbsp;Golden Street, New York,USA
                        </div>
                            </li>
                           
                        </ul>
                    </div>
                    <div className="social">
                       <h5>Follow Us</h5>
<FaFacebookF className='socialIcon'/>
<FaXTwitter className='socialIcon'/>
<FaSquareInstagram className='socialIcon'></FaSquareInstagram>
                    </div>
                </div>
            </div>
            {/* <div className="row copyright">
            © Copyright 2020 by XYZ

   
            </div> */}
        </footer>
    </div>
  )
}

export default Footer