import React,{useEffect} from 'react'
import NavBar from './Navbar'
import '../css/contact.css'
import AOS from "aos";
import "aos/dist/aos.css";
import {Link} from 'react-router-dom'

function Contact() {
    useEffect(() => {
        AOS.init({ duration: "900" });
      }, [])
  return (
    <div>
           <div className="contactbanner">
        <NavBar/>
        <div className="innerDiv">
          <h1>Contac Us</h1>
          <div className="breadcrumbdiv">
          <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item "><Link to="/">Home</Link></li>
    <li class="breadcrumb-item " ><Link to="/contactus">Contact Us</Link></li>
  </ol>
</nav>
          </div>
        </div>
      </div>

      <div className="cotainer-fluid mt-4 contactUsContainer" data-aos='slide-up'>
        <div className="row  d-flex align-items-center justify-content-center " style={{width:'100%'}}>
            <div className="col-md-7 " >
               {/* <h2>
                <b>Contact Info</b>
               </h2>
               <p className='p'>Thank you for your interest in [Company Name]. Please feel free to reach out to us with any questions, inquiries, or to request a quote. Our dedicated team is ready to assist you.</p>
               <br /> */}
       <div className="row d-flex align-items-center justify-content-center ">
        <div className="col-md-12 gy-3  d-flex align-items-center justify-content-center">
        <div class="card border-0" style={{width: '25rem',boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px'}} data-aos='slide-up'>
  <div class="card-body">
    <img src="../images/call.png" alt="" srcset="" className='callImg'/>
  <h6 class="card-subtitle mb-2 text-muted">Contact Number</h6>
    <h5 class="card-title">+91-98765341</h5>
   
    
  </div>
</div>
        </div>
        <div className="col-md-12 gy-3 d-flex align-items-center justify-content-center">
        <div class="card border-0" style={{width: '25rem',boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px'}} data-aos='slide-up'>
  <div class="card-body">
    <img src="../images/email.png" alt="" srcset="" className='callImg'/>
  <h6 class="card-subtitle mb-2 text-muted">Email Address</h6>
    <h5 class="card-title">needhelp@gmail.com</h5>

  </div>
</div>
        </div>
        <div className="col-md-12 gy-3 d-flex align-items-center justify-content-center">
        <div class="card border-0" style={{width: '25rem',boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px'}} data-aos='slide-up'>
  <div class="card-body">
    <img src="../images/location.png" alt="" srcset="" className='callImg'/>
  <h6 class="card-subtitle mb-2 text-muted">Address</h6>
    <h5 class="card-title">80 Brooklyn Golden Street, New York,USA</h5>    
  </div>
</div>
        </div>
       </div>
            </div>
            <div className="col-md-5 mt-5 d-flex flex-column align-items-center" >
            <div className="row">
    <h5 className="contactHead">CONTACT US</h5>
  </div>
  <div className="row text-START d-flex ">
    <h1 className="contactHead2">FEEL FREE TO CONTACT & HIRE US !!</h1>
  </div>
                <input type="text" name=""  placeholder='Your Name'  className='inputBox' required/>
                <input type="email" name="" id="" required placeholder='Email Address' className='inputBox'/>
                <input type="tel" name="" id="" required placeholder='Phone Number' className='inputBox'/>
                <input type="text" name="" id="" required placeholder='Subject' className='inputBox'/>
                <textarea name="" id="" required placeholder='Message' className='textArea'></textarea>
                <button type="submit" required className='submit'>SEND A MESSAGE</button>
                
            </div>
        </div>
      </div>
    </div>
  )
}

export default Contact